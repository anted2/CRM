import { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { Button } from '@/app/components/ui/button';

import InicioScreen from '@/app/components/InicioScreen';
import AnalistScreen from '@/app/components/AnalistScreen';

import DashboardScreen from '@/app/components/DashboardScreen';
import LeadScreen from '@/app/components/LeadScreen';
import ContactsScreen from '@/app/components/ContactsScreen';
import CompaniesScreen from '@/app/components/CompaniesScreen';
import DealsScreen from '@/app/components/DealsScreen';
import DealDetailScreen from '@/app/components/DealDetailScreen';
import QuotesScreen from '@/app/components/QuotesScreen';
import ApprovalsScreen from '@/app/components/ApprovalsScreen';
import AwardedPOScreen from '@/app/components/AwardedPOScreen';
import OrdersScreen from '@/app/components/OrdersScreen';
import ProjectsScreen from '@/app/components/ProjectsScreen';
import TasksScreen from '@/app/components/TasksScreen';
import CallsScreen from '@/app/components/CallsScreen';
import LeadEvaluationScreen from '@/app/components/LeadEvaluationScreen';

const screens = [
  { id: 0, title: 'Inicio', component: InicioScreen },
  { id: 1, title: 'KPI', component: DashboardScreen },
  { id: 2, title: 'Registro de Lead', component: LeadScreen },
  { id: 3, title: 'Evaluación de Lead', component: LeadEvaluationScreen },
  { id: 4, title: 'Contactos', component: ContactsScreen },
  { id: 5, title: 'Empresas', component: CompaniesScreen },
  { id: 6, title: 'Negocios - Pipeline EPC', component: DealsScreen },
  { id: 7, title: 'Negocio - Vista Detalle', component: DealDetailScreen },
  { id: 8, title: 'Quotes (Cotizaciones)', component: QuotesScreen },
  { id: 9, title: 'Awarded vs Pending PO', component: AwardedPOScreen },
  { id: 10, title: 'Pedidos (Orders)', component: OrdersScreen },
  { id: 12, title: 'Llamadas', component: CallsScreen },
  { id: 13, title: 'Análisis', component: AnalistScreen },
];

export default function App() {
  // ✅ Inicia en Inicio (index 0)
  const [currentScreen, setCurrentScreen] = useState(0);

  // ✅ Controla si el sidebar está abierto/cerrado (desktop)
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // ✅ Controla drawer en mobile
  const [mobileOpen, setMobileOpen] = useState(false);

  const handlePrevious = () => {
    setCurrentScreen((prev) => (prev > 0 ? prev - 1 : screens.length - 1));
  };

  const handleNext = () => {
    setCurrentScreen((prev) => (prev < screens.length - 1 ? prev + 1 : 0));
  };

  // ⚠️ tip: casteo para evitar error TS cuando pasamos props a pantallas que no las usan
  const CurrentComponent = screens[currentScreen].component as any;

  const goToScreen = (index: number) => {
    setCurrentScreen(index);
    setMobileOpen(false); // en móvil, cierra drawer al elegir pantalla
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* ====== MOBILE DRAWER OVERLAY ====== */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/30 z-40 lg:hidden"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* ====== SIDEBAR (DESKTOP COLLAPSIBLE + MOBILE DRAWER) ====== */}
      <aside
        className={`
          bg-white border-r border-gray-200 flex flex-col z-50
          fixed lg:static inset-y-0 left-0
          transition-all duration-200
          ${mobileOpen ? 'translate-x-0' : 'translate-x-[-100%] lg:translate-x-0'}
          ${sidebarOpen ? 'w-64' : 'w-16'}
        `}
      >
        {/* Sidebar Header */}
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 flex items-center justify-between">
          <div className={`${sidebarOpen ? 'block' : 'hidden'} transition-all`}>
            <h1 className="text-lg font-bold leading-tight">DINAMO CRM</h1>
            <p className="text-xs text-blue-100">Ingeniería y Construcción</p>
          </div>

          {/* Botón cerrar en MOBILE */}
          <button
            className="lg:hidden p-2 rounded hover:bg-white/10"
            onClick={() => setMobileOpen(false)}
            aria-label="Cerrar menú"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Botón colapsar en DESKTOP */}
          <button
            className="hidden lg:inline-flex p-2 rounded hover:bg-white/10"
            onClick={() => setSidebarOpen((v) => !v)}
            aria-label={sidebarOpen ? 'Colapsar menú' : 'Expandir menú'}
            title={sidebarOpen ? 'Colapsar' : 'Expandir'}
          >
            {sidebarOpen ? (
              <PanelLeftClose className="h-5 w-5" />
            ) : (
              <PanelLeftOpen className="h-5 w-5" />
            )}
          </button>
        </div>

        {/* Navigation List */}
        <nav className="flex-1 overflow-y-auto p-3">
          <div className="space-y-1">
            {screens.map((screen, index) => (
              <button
                key={screen.id}
                onClick={() => goToScreen(index)}
                className={`
                  w-full text-left px-3 py-3 text-sm rounded-lg transition-colors
                  flex items-center gap-2
                  ${
                    currentScreen === index
                      ? 'bg-blue-600 text-white font-medium'
                      : 'text-gray-700 hover:bg-gray-100'
                  }
                `}
                title={!sidebarOpen ? screen.title : undefined}
              >
                <span className="text-xs opacity-70 w-6 text-right">{index + 1}.</span>

                {/* Texto solo si está abierto */}
                {sidebarOpen && <span className="truncate">{screen.title}</span>}
              </button>
            ))}
          </div>
        </nav>

        {/* Navigation Controls */}
        <div className="p-3 border-t border-gray-200 space-y-2">
          <Button
            onClick={handlePrevious}
            variant="outline"
            size="sm"
            className={`w-full ${sidebarOpen ? '' : 'px-0'}`}
            title="Anterior"
          >
            <ChevronLeft className="h-4 w-4" />
            {sidebarOpen && <span className="ml-1">Anterior</span>}
          </Button>

          <Button
            onClick={handleNext}
            variant="outline"
            size="sm"
            className={`w-full ${sidebarOpen ? '' : 'px-0'}`}
            title="Siguiente"
          >
            {sidebarOpen && <span className="mr-1">Siguiente</span>}
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </aside>

      {/* ====== MAIN CONTENT AREA ====== */}
      <div className="flex-1 flex flex-col min-w-0 lg:ml-0">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 py-4 px-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl text-gray-900">{screens[currentScreen].title}</h2>
            <p className="text-sm text-gray-500">
              Pantalla {currentScreen + 1} de {screens.length}
            </p>
          </div>

          {/* Botón hamburguesa SOLO en MOBILE */}
          <button
            className="lg:hidden inline-flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50"
            onClick={() => setMobileOpen(true)}
            aria-label="Abrir menú"
          >
            <Menu className="h-5 w-5 text-gray-700" />
            <span className="text-sm text-gray-700">Menú</span>
          </button>
        </header>

        {/* Main Content */}
        <main className="flex-1 overflow-auto bg-gray-50">
          {/* ✅ Pasamos goToScreen (Inicio lo usa, las demás lo ignoran) */}
          <CurrentComponent goToScreen={goToScreen} />
        </main>
      </div>
    </div>
  );
}