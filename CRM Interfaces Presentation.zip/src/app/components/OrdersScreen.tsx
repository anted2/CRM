import { Search, Filter, Download, Package, AlertCircle, CheckCircle, Clock } from 'lucide-react';

export default function OrdersScreen() {
  const orders = [
    {
      id: 'PO-2024-0089',
      project: 'Planta Petroquímica Altamira',
      supplier: 'Aceros del Norte S.A.',
      description: 'Tubería API 5L X65 - 24" x 12mm',
      amount: 2850000,
      date: '2024-01-10',
      deliveryDate: '2024-03-15',
      status: 'En tránsito',
      progress: 65,
    },
    {
      id: 'PO-2024-0091',
      project: 'Refinería Dos Bocas',
      supplier: 'Válvulas Industriales MX',
      description: 'Válvulas de compuerta clase 900',
      amount: 1250000,
      date: '2024-01-12',
      deliveryDate: '2024-02-28',
      status: 'Entregado',
      progress: 100,
    },
    {
      id: 'PO-2024-0095',
      project: 'Terminal GNL Manzanillo',
      supplier: 'Instrumentación Técnica',
      description: 'Transmisores de presión y temperatura',
      amount: 890000,
      date: '2024-01-15',
      deliveryDate: '2024-02-20',
      status: 'Pendiente',
      progress: 20,
    },
    {
      id: 'PO-2024-0098',
      project: 'Planta Petroquímica Altamira',
      supplier: 'Bombas y Sistemas SA',
      description: 'Bombas centrífugas API 610',
      amount: 3200000,
      date: '2024-01-18',
      deliveryDate: '2024-04-10',
      status: 'En fabricación',
      progress: 45,
    },
    {
      id: 'PO-2024-0102',
      project: 'Refinería Dos Bocas',
      supplier: 'Cableado Industrial Pro',
      description: 'Cable de instrumentación 18 AWG',
      amount: 450000,
      date: '2024-01-20',
      deliveryDate: '2024-03-05',
      status: 'En tránsito',
      progress: 70,
    },
    {
      id: 'PO-2024-0105',
      project: 'Central Cogeneración Veracruz',
      supplier: 'Estructuras Metálicas del Golfo',
      description: 'Estructuras de acero ASTM A36',
      amount: 1980000,
      date: '2024-01-22',
      deliveryDate: '2024-03-20',
      status: 'En fabricación',
      progress: 35,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Entregado':
        return 'bg-green-100 text-green-800';
      case 'En tránsito':
        return 'bg-blue-100 text-blue-800';
      case 'En fabricación':
        return 'bg-yellow-100 text-yellow-800';
      case 'Pendiente':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Entregado':
        return <CheckCircle className="h-4 w-4" />;
      case 'En tránsito':
      case 'En fabricación':
        return <Clock className="h-4 w-4" />;
      case 'Pendiente':
        return <AlertCircle className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const totalOrders = orders.length;
  const totalAmount = orders.reduce((sum, order) => sum + order.amount, 0);
  const deliveredCount = orders.filter((o) => o.status === 'Entregado').length;
  const inTransitCount = orders.filter((o) => o.status === 'En tránsito').length;

  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      {/* KPIs Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-5 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Órdenes</p>
              <p className="text-2xl font-semibold text-gray-900 mt-1">{totalOrders}</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Package className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Monto Total</p>
              <p className="text-2xl font-semibold text-gray-900 mt-1">
                ${(totalAmount / 1000000).toFixed(1)}M
              </p>
            </div>
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Package className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Entregados</p>
              <p className="text-2xl font-semibold text-green-600 mt-1">{deliveredCount}</p>
            </div>
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-5 border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">En Tránsito</p>
              <p className="text-2xl font-semibold text-blue-600 mt-1">{inTransitCount}</p>
            </div>
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="bg-white rounded-lg shadow border border-gray-200">
        {/* Header */}
        <div className="border-b border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Órdenes de Compra</h2>
              <p className="text-sm text-gray-600 mt-1">Gestión de pedidos y seguimiento de entregas</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
              <Download className="h-4 w-4" />
              Exportar
            </button>
          </div>

          {/* Search and Filters */}
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar por PO, proyecto o proveedor..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Filter className="h-4 w-4" />
              Filtros
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Orden de Compra
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Proyecto
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Proveedor
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Descripción
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Monto
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Fecha Entrega
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Estado
                </th>
                <th className="text-left py-3 px-6 text-xs font-medium text-gray-600 uppercase tracking-wider">
                  Progreso
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-gray-400" />
                      <span className="font-medium text-blue-600 hover:underline cursor-pointer">
                        {order.id}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{order.project}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-900">{order.supplier}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-600">{order.description}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm font-medium text-gray-900">
                      ${order.amount.toLocaleString('es-MX')}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <span className="text-sm text-gray-600">{order.deliveryDate}</span>
                  </td>
                  <td className="py-4 px-6">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(
                        order.status
                      )}`}
                    >
                      {getStatusIcon(order.status)}
                      {order.status}
                    </span>
                  </td>
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 max-w-[100px]">
                        <div
                          className={`h-2 rounded-full ${
                            order.progress === 100 ? 'bg-green-500' : 'bg-blue-500'
                          }`}
                          style={{ width: `${order.progress}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-600 w-10 text-right">{order.progress}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 px-6 py-4 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Mostrando <span className="font-medium">{orders.length}</span> órdenes de compra
          </p>
          <div className="flex gap-2">
            <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 text-sm">
              Anterior
            </button>
            <button className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
              1
            </button>
            <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 text-sm">
              2
            </button>
            <button className="px-3 py-1 border border-gray-300 rounded hover:bg-gray-50 text-sm">
              Siguiente
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
