import * as React from 'react';
import {
  Search,
  Filter,
  MoreVertical,
  Building2,
  User,
  Clock,
  X,
  AlertTriangle,
  ChevronDown,
} from 'lucide-react';

import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Card } from '@/app/components/ui/card';

type CompanyType = 'Cliente final' | 'EPC' | 'Integrador' | 'Proveedor';
type Industry = 'Minería' | 'Energía' | 'Industria' | 'Oil & Gas' | 'Construcción' | 'Otros';

type RoleInProject = 'Decisor' | 'Técnico' | 'Compras' | 'Operaciones' | 'Otro';
type Influence = 'Alta' | 'Media' | 'Baja';

type DealStage =
  | 'Lead recibido'
  | 'Evaluación'
  | 'Qualified Lead'
  | 'Opportunity (Budget Quote)'
  | 'Quote (Pending)'
  | 'Awarded'
  | 'Pending PO'
  | 'Won (Order)'
  | 'Lost'
  | 'Cancelled';

type Company = {
  id: string;
  name: string;
  type: CompanyType;
  industry: Industry;
  country: string;
  city: string;
  owner: string; // dueño de la cuenta (account owner)
};

type Deal = {
  id: string;
  name: string;
  companyId: string;
  stage: DealStage;
  owner: string; // dueño del negocio
  amountUsd: number;

  // EPC / red flags
  quoteDueIso?: string; // si stage Quote (Pending)
  awardedIso?: string; // si stage Awarded/Pending PO
  poReceived?: boolean;
};

type Contact = {
  id: string;
  name: string;
  email: string;
  phone: string;

  roleInProject: RoleInProject;
  influence: Influence;

  companyId: string;
  owner: string; // owner del contacto

  lastActivityIso: string; // YYYY-MM-DD
  createdIso: string; // YYYY-MM-DD

  // relación con deals (importante para filtros “por Negocio”)
  dealIds: string[];
};

type ViewKey = 'ALL' | 'NEEDS_FOLLOW_UP' | 'OPEN_DEALS' | 'RED_FLAGS';

type FiltersState = {
  q: string;

  // Contact filters
  owner: 'Todos' | string;
  role: 'Todos' | RoleInProject;
  influence: 'Todas' | Influence;
  hasEmail: 'Todos' | 'Sí' | 'No';
  hasPhone: 'Todos' | 'Sí' | 'No';
  inactiveDays: 'Todos' | '7+' | '14+' | '30+';
  createdIn: 'Todos' | '30d' | '90d' | '180d';

  // Company-related filters (by relationship)
  companyId: 'Todas' | string;
  companyType: 'Todos' | CompanyType;
  industry: 'Todas' | Industry;
  country: 'Todos' | string;
  city: 'Todas' | string;
  companyOwner: 'Todos' | string;

  // Deal-related filters (by relationship)
  hasOpenDeals: 'Todos' | 'Sí' | 'No';
  dealStage: 'Todas' | DealStage;
  dealOwner: 'Todos' | string;

  // EPC Red flags (by relationship)
  onlyRedFlags: boolean;
  onlyAwardedNoPO: boolean;
  quoteDue: 'Todos' | 'Vence<=3d' | 'Vencida';
};

function unique(list: string[]) {
  return Array.from(new Set(list)).sort((a, b) => a.localeCompare(b));
}

function daysBetween(aIso: string, bIso: string) {
  const a = new Date(`${aIso}T00:00:00`);
  const b = new Date(`${bIso}T00:00:00`);
  return Math.round((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24));
}

function toISODateLabel(iso: string) {
  const [y, m, d] = iso.split('-').map(Number);
  const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  return `${d} ${months[(m || 1) - 1]} ${y}`;
}

function chipLabel(key: string, value: string) {
  return `${key}: ${value}`;
}

function isOpenStage(stage: DealStage) {
  return !['Won (Order)', 'Lost', 'Cancelled'].includes(stage);
}

function stageBadge(stage: DealStage) {
  const m: Partial<Record<DealStage, string>> = {
    'Lead recibido': 'bg-gray-100 text-gray-700',
    'Evaluación': 'bg-gray-100 text-gray-700',
    'Qualified Lead': 'bg-slate-100 text-slate-700',
    'Opportunity (Budget Quote)': 'bg-indigo-100 text-indigo-700',
    'Quote (Pending)': 'bg-blue-100 text-blue-700',
    'Awarded': 'bg-green-100 text-green-700',
    'Pending PO': 'bg-orange-100 text-orange-700',
    'Won (Order)': 'bg-emerald-100 text-emerald-700',
    'Lost': 'bg-red-100 text-red-700',
    'Cancelled': 'bg-rose-100 text-rose-700',
  };
  return m[stage] || 'bg-gray-100 text-gray-700';
}

function roleBadge(role: RoleInProject) {
  const map: Record<RoleInProject, string> = {
    Decisor: 'bg-green-100 text-green-700',
    Técnico: 'bg-blue-100 text-blue-700',
    Compras: 'bg-orange-100 text-orange-700',
    Operaciones: 'bg-purple-100 text-purple-700',
    Otro: 'bg-gray-100 text-gray-700',
  };
  return map[role];
}

function influenceBadge(inf: Influence) {
  const map: Record<Influence, string> = {
    Alta: 'bg-emerald-100 text-emerald-700',
    Media: 'bg-yellow-100 text-yellow-700',
    Baja: 'bg-gray-100 text-gray-700',
  };
  return map[inf];
}

export default function ContactsScreen() {
  // Demo "hoy"
  const todayIso = '2026-01-16';

  // -----------------------
  // MOCK DATA RELACIONADA
  // -----------------------
  const companies: Company[] = [
    {
      id: 'co1',
      name: 'ACME Mining',
      type: 'Cliente final',
      industry: 'Minería',
      country: 'Perú',
      city: 'Lima',
      owner: 'Antonys',
    },
    {
      id: 'co2',
      name: 'EPC Delta',
      type: 'EPC',
      industry: 'Energía',
      country: 'Chile',
      city: 'Antofagasta',
      owner: 'Enzo',
    },
    {
      id: 'co3',
      name: 'PetroChemical Corp',
      type: 'Cliente final',
      industry: 'Oil & Gas',
      country: 'Perú',
      city: 'Callao',
      owner: 'Ana',
    },
  ];

  const deals: Deal[] = [
    {
      id: 'd1',
      name: 'Balsa grating - ACME',
      companyId: 'co1',
      stage: 'Quote (Pending)',
      owner: 'Antony',
      amountUsd: 55000,
      quoteDueIso: '2026-01-20',
      poReceived: false,
    },
    {
      id: 'd2',
      name: 'Muelle flotante - EPC Delta',
      companyId: 'co2',
      stage: 'Awarded',
      owner: 'Enzo',
      amountUsd: 95000,
      awardedIso: '2026-01-08',
      poReceived: false,
    },
    {
      id: 'd3',
      name: 'Proyecto buzos - ACME',
      companyId: 'co1',
      stage: 'Pending PO',
      owner: 'Antony',
      amountUsd: 60000,
      awardedIso: '2026-01-02',
      poReceived: false,
    },
    {
      id: 'd4',
      name: 'Inspección marina - PetroChemical',
      companyId: 'co3',
      stage: 'Won (Order)',
      owner: 'Ana',
      amountUsd: 15000,
      poReceived: true,
    },
  ];

  const contacts: Contact[] = [
    {
      id: 'p1',
      name: 'Juan Pérez',
      email: 'jperez@cliente.com',
      phone: '+51 999 111 222',
      roleInProject: 'Técnico',
      influence: 'Media',
      companyId: 'co1',
      owner: 'Antony',
      lastActivityIso: '2026-01-16',
      createdIso: '2025-11-05',
      dealIds: ['d1', 'd3'],
    },
    {
      id: 'p2',
      name: 'María Ruiz',
      email: 'mruiz@epc.com',
      phone: '+51 988 333 444',
      roleInProject: 'Compras',
      influence: 'Alta',
      companyId: 'co2',
      owner: 'Enzo',
      lastActivityIso: '2026-01-15',
      createdIso: '2025-12-10',
      dealIds: ['d2'],
    },
    {
      id: 'p3',
      name: 'Carlos Vega',
      email: 'cvega@cliente.com',
      phone: '+56 912 555 666',
      roleInProject: 'Decisor',
      influence: 'Alta',
      companyId: 'co1',
      owner: 'Antony',
      lastActivityIso: '2026-01-07',
      createdIso: '2025-07-20',
      dealIds: ['d1'],
    },
    {
      id: 'p4',
      name: 'Lucía Campos',
      email: '',
      phone: '+51 944 222 111',
      roleInProject: 'Operaciones',
      influence: 'Baja',
      companyId: 'co3',
      owner: 'Ana',
      lastActivityIso: '2025-12-20',
      createdIso: '2026-01-05',
      dealIds: ['d4'],
    },
  ];

  // Indexes for fast relationship lookups
  const companyById = React.useMemo(() => {
    const m = new Map<string, Company>();
    companies.forEach(c => m.set(c.id, c));
    return m;
  }, [companies]);

  const dealById = React.useMemo(() => {
    const m = new Map<string, Deal>();
    deals.forEach(d => m.set(d.id, d));
    return m;
  }, [deals]);

  // -----------------------
  // STATE
  // -----------------------
  const [activeView, setActiveView] = React.useState<ViewKey>('ALL');
  const [showFilters, setShowFilters] = React.useState(false);

  const [filters, setFilters] = React.useState<FiltersState>({
    q: '',

    owner: 'Todos',
    role: 'Todos',
    influence: 'Todas',
    hasEmail: 'Todos',
    hasPhone: 'Todos',
    inactiveDays: 'Todos',
    createdIn: 'Todos',

    companyId: 'Todas',
    companyType: 'Todos',
    industry: 'Todas',
    country: 'Todos',
    city: 'Todas',
    companyOwner: 'Todos',

    hasOpenDeals: 'Todos',
    dealStage: 'Todas',
    dealOwner: 'Todos',

    onlyRedFlags: false,
    onlyAwardedNoPO: false,
    quoteDue: 'Todos',
  });

  // pagination
  const [page, setPage] = React.useState(1);
  const pageSize = 10;

  // -----------------------
  // OPTIONS (RELACIONADAS)
  // -----------------------
  const contactOwners = React.useMemo(() => ['Todos', ...unique(contacts.map(c => c.owner))], [contacts]);
  const companyOwners = React.useMemo(() => ['Todos', ...unique(companies.map(c => c.owner))], [companies]);
  const dealOwners = React.useMemo(() => ['Todos', ...unique(deals.map(d => d.owner))], [deals]);

  const companyOptions = React.useMemo(
    () => ['Todas', ...companies.map(c => c.id)],
    [companies]
  );

  const companyName = (id: string) => companyById.get(id)?.name ?? id;

  const countryOptions = React.useMemo(() => ['Todos', ...unique(companies.map(c => c.country))], [companies]);

  // City options depend on selected country (RELACIONADO)
  const cityOptions = React.useMemo(() => {
    const relevant = companies.filter(c => (filters.country === 'Todos' ? true : c.country === filters.country));
    return ['Todas', ...unique(relevant.map(c => c.city))];
  }, [companies, filters.country]);

  // Deal stages options from data (RELACIONADO)
  const dealStageOptions = React.useMemo(() => ['Todas', ...unique(deals.map(d => d.stage))] as Array<FiltersState['dealStage']>, [deals]);

  // -----------------------
  // RED FLAGS (RELACIONADO A DEALS)
  // -----------------------
  function getContactDeals(contact: Contact): Deal[] {
    return contact.dealIds.map(id => dealById.get(id)).filter(Boolean) as Deal[];
  }

  function computeDealRedFlags(d: Deal): string[] {
    const flags: string[] = [];

    // Quote due soon / expired
    if (d.stage === 'Quote (Pending)' && d.quoteDueIso) {
      const delta = daysBetween(todayIso, d.quoteDueIso);
      if (delta < 0) flags.push('Quote vencida');
      else if (delta <= 3) flags.push(`Quote vence en ${delta} día${delta === 1 ? '' : 's'}`);
    }

    // Awarded/Pending PO without PO too long
    if ((d.stage === 'Awarded' || d.stage === 'Pending PO') && d.poReceived === false && d.awardedIso) {
      const days = daysBetween(d.awardedIso, todayIso);
      if (days >= 10) flags.push(`Sin PO hace ${days} días`);
      else if (days >= 7) flags.push(`PO pendiente (${days} días)`);
    }

    return flags;
  }

  function contactHasAnyRedFlag(contact: Contact) {
    const ds = getContactDeals(contact);
    return ds.some(d => computeDealRedFlags(d).length > 0);
  }

  function contactHasAwardedNoPO(contact: Contact) {
    const ds = getContactDeals(contact);
    return ds.some(d => (d.stage === 'Awarded' || d.stage === 'Pending PO') && d.poReceived === false);
  }

  function contactHasOpenDeals(contact: Contact) {
    const ds = getContactDeals(contact);
    return ds.some(d => isOpenStage(d.stage));
  }

  // -----------------------
  // VIEWS (TABS) TIPO HUBSPOT
  // -----------------------
  const viewPredicate = React.useCallback(
    (c: Contact) => {
      if (activeView === 'ALL') return true;

      if (activeView === 'OPEN_DEALS') return contactHasOpenDeals(c);

      if (activeView === 'NEEDS_FOLLOW_UP') {
        const inactive = daysBetween(c.lastActivityIso, todayIso);
        return inactive >= 7;
      }

      if (activeView === 'RED_FLAGS') {
        return contactHasAnyRedFlag(c);
      }

      return true;
    },
    [activeView, todayIso]
  );

  // -----------------------
  // FILTER ENGINE (RELACIONADO)
  // -----------------------
  const filteredContacts = React.useMemo(() => {
    const q = filters.q.trim().toLowerCase();

    const createdThresholdDays = (v: FiltersState['createdIn']) => {
      if (v === '30d') return 30;
      if (v === '90d') return 90;
      if (v === '180d') return 180;
      return null;
    };

    const inactiveThresholdDays = (v: FiltersState['inactiveDays']) => {
      if (v === '7+') return 7;
      if (v === '14+') return 14;
      if (v === '30+') return 30;
      return null;
    };

    return contacts
      .filter(viewPredicate)
      .filter(c => {
        const co = companyById.get(c.companyId);
        const ds = getContactDeals(c);

        // --- CONTACT FILTERS ---
        if (filters.owner !== 'Todos' && c.owner !== filters.owner) return false;
        if (filters.role !== 'Todos' && c.roleInProject !== filters.role) return false;
        if (filters.influence !== 'Todas' && c.influence !== filters.influence) return false;

        if (filters.hasEmail !== 'Todos') {
          const has = Boolean(c.email?.trim());
          if ((filters.hasEmail === 'Sí') !== has) return false;
        }

        if (filters.hasPhone !== 'Todos') {
          const has = Boolean(c.phone?.trim());
          if ((filters.hasPhone === 'Sí') !== has) return false;
        }

        if (filters.inactiveDays !== 'Todos') {
          const th = inactiveThresholdDays(filters.inactiveDays);
          if (th != null) {
            const inactive = daysBetween(c.lastActivityIso, todayIso);
            if (inactive < th) return false;
          }
        }

        if (filters.createdIn !== 'Todos') {
          const th = createdThresholdDays(filters.createdIn);
          if (th != null) {
            const age = daysBetween(c.createdIso, todayIso);
            if (age > th) return false; // “creados en los últimos X días”
          }
        }

        // --- COMPANY FILTERS (RELACIONADOS) ---
        if (filters.companyId !== 'Todas' && c.companyId !== filters.companyId) return false;
        if (filters.companyType !== 'Todos') {
          if (!co) return false;
          if (co.type !== filters.companyType) return false;
        }
        if (filters.industry !== 'Todas') {
          if (!co) return false;
          if (co.industry !== filters.industry) return false;
        }
        if (filters.country !== 'Todos') {
          if (!co) return false;
          if (co.country !== filters.country) return false;
        }
        if (filters.city !== 'Todas') {
          if (!co) return false;
          if (co.city !== filters.city) return false;
        }
        if (filters.companyOwner !== 'Todos') {
          if (!co) return false;
          if (co.owner !== filters.companyOwner) return false;
        }

        // --- DEAL FILTERS (RELACIONADOS) ---
        if (filters.hasOpenDeals !== 'Todos') {
          const has = ds.some(d => isOpenStage(d.stage));
          if ((filters.hasOpenDeals === 'Sí') !== has) return false;
        }

        if (filters.dealStage !== 'Todas') {
          const match = ds.some(d => d.stage === filters.dealStage);
          if (!match) return false;
        }

        if (filters.dealOwner !== 'Todos') {
          const match = ds.some(d => d.owner === filters.dealOwner);
          if (!match) return false;
        }

        // --- EPC FLAGS (RELACIONADOS) ---
        if (filters.onlyRedFlags) {
          if (!ds.some(d => computeDealRedFlags(d).length > 0)) return false;
        }

        if (filters.onlyAwardedNoPO) {
          if (!ds.some(d => (d.stage === 'Awarded' || d.stage === 'Pending PO') && d.poReceived === false)) return false;
        }

        if (filters.quoteDue !== 'Todos') {
          const match = ds.some(d => {
            if (d.stage !== 'Quote (Pending)' || !d.quoteDueIso) return false;
            const delta = daysBetween(todayIso, d.quoteDueIso);
            if (filters.quoteDue === 'Vencida') return delta < 0;
            if (filters.quoteDue === 'Vence<=3d') return delta >= 0 && delta <= 3;
            return false;
          });
          if (!match) return false;
        }

        // --- SEARCH ---
        if (q) {
          const companyStr = co ? `${co.name} ${co.type} ${co.industry} ${co.country} ${co.city}` : '';
          const dealsStr = ds.map(d => `${d.name} ${d.stage} ${d.owner}`).join(' ');
          const hay = `${c.name} ${c.email} ${c.phone} ${c.roleInProject} ${c.influence} ${c.owner} ${companyStr} ${dealsStr}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }

        return true;
      })
      .sort((a, b) => b.lastActivityIso.localeCompare(a.lastActivityIso));
  }, [contacts, filters, viewPredicate, companyById, dealById, todayIso]);

  React.useEffect(() => {
    setPage(1);
  }, [filters, activeView]);

  const totalPages = Math.max(1, Math.ceil(filteredContacts.length / pageSize));
  const pageSafe = Math.min(page, totalPages);
  const startIdx = (pageSafe - 1) * pageSize;
  const pageRows = filteredContacts.slice(startIdx, startIdx + pageSize);

  // -----------------------
  // FILTER CHIPS (VISUAL + RESET)
  // -----------------------
  const activeChips = React.useMemo(() => {
    const chips: Array<{ key: string; value: string; onClear: () => void }> = [];

    const add = (key: string, value: string, onClear: () => void) => chips.push({ key, value, onClear });

    if (filters.q) add('Buscar', `"${filters.q}"`, () => setFilters(p => ({ ...p, q: '' })));
    if (filters.owner !== 'Todos') add('Owner', filters.owner, () => setFilters(p => ({ ...p, owner: 'Todos' })));
    if (filters.role !== 'Todos') add('Rol', filters.role, () => setFilters(p => ({ ...p, role: 'Todos' })));
    if (filters.influence !== 'Todas') add('Influencia', filters.influence, () => setFilters(p => ({ ...p, influence: 'Todas' })));

    if (filters.companyId !== 'Todas') add('Empresa', companyName(filters.companyId), () => setFilters(p => ({ ...p, companyId: 'Todas' })));
    if (filters.companyType !== 'Todos') add('Tipo empresa', filters.companyType, () => setFilters(p => ({ ...p, companyType: 'Todos' })));
    if (filters.industry !== 'Todas') add('Industria', filters.industry, () => setFilters(p => ({ ...p, industry: 'Todas' })));
    if (filters.country !== 'Todos') add('País', filters.country, () => setFilters(p => ({ ...p, country: 'Todos' })));
    if (filters.city !== 'Todas') add('Ciudad', filters.city, () => setFilters(p => ({ ...p, city: 'Todas' })));
    if (filters.companyOwner !== 'Todos') add('Owner empresa', filters.companyOwner, () => setFilters(p => ({ ...p, companyOwner: 'Todos' })));

    if (filters.hasOpenDeals !== 'Todos') add('Deals abiertos', filters.hasOpenDeals, () => setFilters(p => ({ ...p, hasOpenDeals: 'Todos' })));
    if (filters.dealStage !== 'Todas') add('Etapa deal', filters.dealStage, () => setFilters(p => ({ ...p, dealStage: 'Todas' })));
    if (filters.dealOwner !== 'Todos') add('Owner deal', filters.dealOwner, () => setFilters(p => ({ ...p, dealOwner: 'Todos' })));

    if (filters.onlyRedFlags) add('Red flags', 'Solo', () => setFilters(p => ({ ...p, onlyRedFlags: false })));
    if (filters.onlyAwardedNoPO) add('Awarded sin PO', 'Solo', () => setFilters(p => ({ ...p, onlyAwardedNoPO: false })));
    if (filters.quoteDue !== 'Todos') add('Quotes', filters.quoteDue, () => setFilters(p => ({ ...p, quoteDue: 'Todos' })));

    if (filters.inactiveDays !== 'Todos') add('Inactividad', filters.inactiveDays, () => setFilters(p => ({ ...p, inactiveDays: 'Todos' })));
    if (filters.createdIn !== 'Todos') add('Creado', filters.createdIn, () => setFilters(p => ({ ...p, createdIn: 'Todos' })));
    if (filters.hasEmail !== 'Todos') add('Email', filters.hasEmail, () => setFilters(p => ({ ...p, hasEmail: 'Todos' })));
    if (filters.hasPhone !== 'Todos') add('Teléfono', filters.hasPhone, () => setFilters(p => ({ ...p, hasPhone: 'Todos' })));

    return chips;
  }, [filters, companyById]);

  const clearAll = () => {
    setFilters({
      q: '',

      owner: 'Todos',
      role: 'Todos',
      influence: 'Todas',
      hasEmail: 'Todos',
      hasPhone: 'Todos',
      inactiveDays: 'Todos',
      createdIn: 'Todos',

      companyId: 'Todas',
      companyType: 'Todos',
      industry: 'Todas',
      country: 'Todos',
      city: 'Todas',
      companyOwner: 'Todos',

      hasOpenDeals: 'Todos',
      dealStage: 'Todas',
      dealOwner: 'Todos',

      onlyRedFlags: false,
      onlyAwardedNoPO: false,
      quoteDue: 'Todos',
    });
  };

  // -----------------------
  // STATS REALES
  // -----------------------
  const stats = React.useMemo(() => {
    const total = filteredContacts.length;
    const openDeals = filteredContacts.filter(c => contactHasOpenDeals(c)).length;
    const followUp = filteredContacts.filter(c => daysBetween(c.lastActivityIso, todayIso) >= 7).length;
    const redFlags = filteredContacts.filter(c => contactHasAnyRedFlag(c)).length;
    return { total, openDeals, followUp, redFlags };
  }, [filteredContacts, todayIso]);

  // -----------------------
  // UI
  // -----------------------
  return (
    <div className="p-8 bg-gray-50 min-h-full">
      <Card className="bg-white border border-gray-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-2xl">Contactos</h2>
              <p className="text-sm text-gray-600 mt-1">
                Filtros reales y relacionados (Empresa + Negocios + EPC red flags)
              </p>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700">+ Registrar Contacto</Button>
          </div>

          {/* Views (tabs) */}
          <div className="flex gap-2 mb-4">
            <Button variant={activeView === 'ALL' ? 'default' : 'outline'} onClick={() => setActiveView('ALL')}>
              Todos
            </Button>
            <Button
              variant={activeView === 'NEEDS_FOLLOW_UP' ? 'default' : 'outline'}
              onClick={() => setActiveView('NEEDS_FOLLOW_UP')}
            >
              Necesitan seguimiento
            </Button>
            <Button
              variant={activeView === 'OPEN_DEALS' ? 'default' : 'outline'}
              onClick={() => setActiveView('OPEN_DEALS')}
            >
              Oportunidades abiertas
            </Button>
            <Button
              variant={activeView === 'RED_FLAGS' ? 'default' : 'outline'}
              onClick={() => setActiveView('RED_FLAGS')}
              className="gap-2"
            >
              <AlertTriangle className="h-4 w-4" />
              Red flags
            </Button>
          </div>

          {/* Search + quick filters */}
          <div className="flex gap-3 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={filters.q}
                onChange={(e) => setFilters(prev => ({ ...prev, q: e.target.value }))}
                placeholder="Buscar (contacto, empresa, industria, país, deal, etapa, owner...)"
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm bg-white"
              />
            </div>

            <select
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
              value={filters.owner}
              onChange={(e) => setFilters(prev => ({ ...prev, owner: e.target.value }))}
            >
              {contactOwners.map(o => (
                <option key={o} value={o}>{o === 'Todos' ? 'Owner contacto: Todos' : `Owner contacto: ${o}`}</option>
              ))}
            </select>

            <Button variant="outline" className="gap-2" onClick={() => setShowFilters(v => !v)}>
              <Filter className="h-4 w-4" />
              Filtros
              <ChevronDown className="h-4 w-4" />
            </Button>

            <Button variant="outline" className="gap-2" onClick={clearAll}>
              <X className="h-4 w-4" />
              Limpiar
            </Button>
          </div>

          {/* Active filter chips */}
          {activeChips.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {activeChips.map((c) => (
                <button
                  key={`${c.key}-${c.value}`}
                  onClick={c.onClear}
                  className="text-xs px-3 py-1 rounded-full border border-gray-200 bg-white hover:bg-gray-50 flex items-center gap-2"
                  title="Quitar filtro"
                >
                  <span className="text-gray-700">{chipLabel(c.key, c.value)}</span>
                  <X className="h-3.5 w-3.5 text-gray-400" />
                </button>
              ))}
            </div>
          )}

          {/* Advanced filters */}
          {showFilters && (
            <div className="mt-4 border border-gray-200 rounded-xl p-4 bg-white">
              <div className="grid grid-cols-12 gap-3">
                {/* CONTACT */}
                <div className="col-span-12">
                  <p className="text-xs font-semibold text-gray-700 mb-2">Filtros de Contacto</p>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Rol en proyecto</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.role}
                    onChange={(e) => setFilters(prev => ({ ...prev, role: e.target.value as FiltersState['role'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Decisor">Decisor</option>
                    <option value="Técnico">Técnico</option>
                    <option value="Compras">Compras</option>
                    <option value="Operaciones">Operaciones</option>
                    <option value="Otro">Otro</option>
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Influencia</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.influence}
                    onChange={(e) => setFilters(prev => ({ ...prev, influence: e.target.value as FiltersState['influence'] }))}
                  >
                    <option value="Todas">Todas</option>
                    <option value="Alta">Alta</option>
                    <option value="Media">Media</option>
                    <option value="Baja">Baja</option>
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Email</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.hasEmail}
                    onChange={(e) => setFilters(prev => ({ ...prev, hasEmail: e.target.value as FiltersState['hasEmail'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Sí">Con email</option>
                    <option value="No">Sin email</option>
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Teléfono</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.hasPhone}
                    onChange={(e) => setFilters(prev => ({ ...prev, hasPhone: e.target.value as FiltersState['hasPhone'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Sí">Con teléfono</option>
                    <option value="No">Sin teléfono</option>
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Sin actividad</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.inactiveDays}
                    onChange={(e) => setFilters(prev => ({ ...prev, inactiveDays: e.target.value as FiltersState['inactiveDays'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="7+">7+ días</option>
                    <option value="14+">14+ días</option>
                    <option value="30+">30+ días</option>
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Creados en</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.createdIn}
                    onChange={(e) => setFilters(prev => ({ ...prev, createdIn: e.target.value as FiltersState['createdIn'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="30d">Últimos 30 días</option>
                    <option value="90d">Últimos 90 días</option>
                    <option value="180d">Últimos 180 días</option>
                  </select>
                </div>

                {/* COMPANY */}
                <div className="col-span-12 mt-2">
                  <p className="text-xs font-semibold text-gray-700 mb-2">Filtros por Empresa (relacionados)</p>
                </div>

                <div className="col-span-4">
                  <label className="text-xs text-gray-600">Empresa</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.companyId}
                    onChange={(e) => setFilters(prev => ({ ...prev, companyId: e.target.value }))}
                  >
                    <option value="Todas">Todas</option>
                    {companies.map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-4">
                  <label className="text-xs text-gray-600">Tipo de empresa</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.companyType}
                    onChange={(e) => setFilters(prev => ({ ...prev, companyType: e.target.value as FiltersState['companyType'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Cliente final">Cliente final</option>
                    <option value="EPC">EPC</option>
                    <option value="Integrador">Integrador</option>
                    <option value="Proveedor">Proveedor</option>
                  </select>
                </div>

                <div className="col-span-4">
                  <label className="text-xs text-gray-600">Industria</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.industry}
                    onChange={(e) => setFilters(prev => ({ ...prev, industry: e.target.value as FiltersState['industry'] }))}
                  >
                    <option value="Todas">Todas</option>
                    <option value="Minería">Minería</option>
                    <option value="Energía">Energía</option>
                    <option value="Industria">Industria</option>
                    <option value="Oil & Gas">Oil & Gas</option>
                    <option value="Construcción">Construcción</option>
                    <option value="Otros">Otros</option>
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">País</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.country}
                    onChange={(e) => setFilters(prev => ({ ...prev, country: e.target.value }))}
                  >
                    {countryOptions.map(c => (
                      <option key={c} value={c}>{c === 'Todos' ? 'Todos' : c}</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Ciudad (depende del país)</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.city}
                    onChange={(e) => setFilters(prev => ({ ...prev, city: e.target.value }))}
                  >
                    {cityOptions.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Owner Empresa</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.companyOwner}
                    onChange={(e) => setFilters(prev => ({ ...prev, companyOwner: e.target.value }))}
                  >
                    {companyOwners.map(o => (
                      <option key={o} value={o}>{o === 'Todos' ? 'Todos' : o}</option>
                    ))}
                  </select>
                </div>

                {/* DEALS */}
                <div className="col-span-12 mt-2">
                  <p className="text-xs font-semibold text-gray-700 mb-2">Filtros por Negocios (Deals) – relacionados</p>
                </div>

                <div className="col-span-3">
                  <label className="text-xs text-gray-600">Tiene deals abiertos</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.hasOpenDeals}
                    onChange={(e) => setFilters(prev => ({ ...prev, hasOpenDeals: e.target.value as FiltersState['hasOpenDeals'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Sí">Sí</option>
                    <option value="No">No</option>
                  </select>
                </div>

                <div className="col-span-5">
                  <label className="text-xs text-gray-600">Etapa del Deal (EPC)</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.dealStage}
                    onChange={(e) => setFilters(prev => ({ ...prev, dealStage: e.target.value as FiltersState['dealStage'] }))}
                  >
                    {dealStageOptions.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>

                <div className="col-span-4">
                  <label className="text-xs text-gray-600">Owner del Deal</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.dealOwner}
                    onChange={(e) => setFilters(prev => ({ ...prev, dealOwner: e.target.value as FiltersState['dealOwner'] }))}
                  >
                    {dealOwners.map(o => (
                      <option key={o} value={o}>{o === 'Todos' ? 'Todos' : o}</option>
                    ))}
                  </select>
                </div>

                {/* EPC RED FLAGS */}
                <div className="col-span-12 mt-2">
                  <p className="text-xs font-semibold text-gray-700 mb-2">EPC – Red Flags</p>
                </div>

                <div className="col-span-3 flex items-end">
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      className="h-4 w-4"
                      checked={filters.onlyRedFlags}
                      onChange={(e) => setFilters(prev => ({ ...prev, onlyRedFlags: e.target.checked }))}
                    />
                    Solo red flags
                  </label>
                </div>

                <div className="col-span-3 flex items-end">
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      className="h-4 w-4"
                      checked={filters.onlyAwardedNoPO}
                      onChange={(e) => setFilters(prev => ({ ...prev, onlyAwardedNoPO: e.target.checked }))}
                    />
                    Solo Awarded sin PO
                  </label>
                </div>

                <div className="col-span-6">
                  <label className="text-xs text-gray-600">Quotes</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={filters.quoteDue}
                    onChange={(e) => setFilters(prev => ({ ...prev, quoteDue: e.target.value as FiltersState['quoteDue'] }))}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Vence<=3d">Vence en 3 días o menos</option>
                    <option value="Vencida">Vencida</option>
                  </select>
                </div>

                <div className="col-span-12 text-xs text-gray-500 mt-1">
                  Nota: Los filtros de “Empresa” y “Deals” se aplican por relación (contacto → empresaId / dealIds).
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 p-6 border-b border-gray-200">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl mb-1">{stats.total}</p>
            <p className="text-xs text-gray-600">Contactos (filtrado)</p>
          </div>
          <div className="text-center p-4 bg-indigo-50 rounded-lg border border-indigo-200">
            <p className="text-2xl text-indigo-700 mb-1">{stats.openDeals}</p>
            <p className="text-xs text-gray-700">Con deals abiertos</p>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg border border-orange-200">
            <p className="text-2xl text-orange-700 mb-1">{stats.followUp}</p>
            <p className="text-xs text-gray-700">Sin actividad ≥ 7 días</p>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg border border-red-200">
            <p className="text-2xl text-red-700 mb-1">{stats.redFlags}</p>
            <p className="text-xs text-gray-700">Con red flags EPC</p>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Contacto</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Rol / Influencia</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Empresa</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Deals (resumen)</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Última actividad</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Owner</th>
                <th className="text-center px-6 py-3 text-xs text-gray-600"></th>
              </tr>
            </thead>

            <tbody>
              {pageRows.map(c => {
                const co = companyById.get(c.companyId);
                const ds = getContactDeals(c);

                const inactive = daysBetween(c.lastActivityIso, todayIso);
                const inactiveLabel = inactive === 0 ? 'hoy' : inactive === 1 ? 'ayer' : `hace ${inactive} días`;

                // show top 1-2 deal stages + red flag marker
                const stages = ds.map(d => d.stage);
                const firstStages = Array.from(new Set(stages)).slice(0, 2);
                const hasRF = ds.some(d => computeDealRedFlags(d).length > 0);

                return (
                  <tr key={c.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-start gap-2">
                        <User className="h-4 w-4 text-gray-400 mt-1" />
                        <div>
                          <p className="text-sm text-gray-900">{c.name}</p>
                          <p className="text-xs text-gray-600">{c.email || '—'} • {c.phone || '—'}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex flex-wrap gap-2">
                        <Badge className={roleBadge(c.roleInProject)}>{c.roleInProject}</Badge>
                        <Badge className={influenceBadge(c.influence)}>{c.influence}</Badge>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Building2 className="h-4 w-4 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-900">{co?.name ?? '—'}</p>
                          <p className="text-xs text-gray-600">
                            {co ? `${co.type} • ${co.industry} • ${co.country}/${co.city}` : '—'}
                          </p>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {hasRF && <AlertTriangle className="h-4 w-4 text-orange-600" title="Tiene red flags EPC" />}
                        <div className="flex flex-wrap gap-2">
                          {firstStages.length === 0 ? (
                            <span className="text-xs text-gray-500">Sin deals</span>
                          ) : (
                            firstStages.map(s => (
                              <Badge key={s} className={stageBadge(s)}>{s}</Badge>
                            ))
                          )}
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <div>
                          <p className="text-sm text-gray-900">{inactiveLabel}</p>
                          <p className="text-xs text-gray-600">{toISODateLabel(c.lastActivityIso)}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-sm text-gray-700">{c.owner}</td>

                    <td className="px-6 py-4 text-center">
                      <Button variant="ghost" size="sm" title="Acciones">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                );
              })}

              {pageRows.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-sm text-gray-600">
                    No hay contactos con los filtros actuales.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer / Pagination */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <span className="text-sm text-gray-600">
            Mostrando {pageRows.length} de {filteredContacts.length} contactos (página {pageSafe} de {totalPages})
          </span>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={pageSafe <= 1}
              onClick={() => setPage(p => Math.max(1, p - 1))}
            >
              Anterior
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={pageSafe >= totalPages}
              onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            >
              Siguiente
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
