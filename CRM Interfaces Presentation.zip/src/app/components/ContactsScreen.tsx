import * as React from 'react';
import { Search, Filter, MoreVertical, Mail, Phone, Building2, X } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Card } from '@/app/components/ui/card';

type Role = 'Decisor' | 'Técnico' | 'Compras';
type LastActivityType = 'Llamada' | 'Email' | 'Reunión' | 'Quote';

type Contact = {
  name: string;
  email: string;
  phone: string;
  role: Role;
  company: string;
  owner: string;

  // Para filtros reales
  lastActivityType: LastActivityType;
  lastActivityDaysAgo: number; // 0 = hoy, 1 = ayer, etc.
  status: 'Activo' | 'No contactado' | 'No califica';
  hasOpenDeals: boolean; // relacionado a Negocios/Deals
};

export default function ContactsScreen() {
  const contacts: Contact[] = [
    {
      name: 'Carlos Méndez',
      email: 'carlos.mendez@petrochemical.com',
      phone: '+52 81 1234 5678',
      role: 'Decisor',
      company: 'PetroChemical Corp',
      owner: 'Ana García',
      lastActivityType: 'Llamada',
      lastActivityDaysAgo: 2,
      status: 'Activo',
      hasOpenDeals: true,
    },
    {
      name: 'María Rodríguez',
      email: 'maria.rodriguez@industrial.com',
      phone: '+52 33 9876 5432',
      role: 'Técnico',
      company: 'Industrial Solutions',
      owner: 'Pedro López',
      lastActivityType: 'Email',
      lastActivityDaysAgo: 1,
      status: 'Activo',
      hasOpenDeals: true,
    },
    {
      name: 'Roberto Sánchez',
      email: 'roberto.sanchez@manufacturing.com',
      phone: '+52 55 2345 6789',
      role: 'Compras',
      company: 'Manufacturing Inc',
      owner: 'Ana García',
      lastActivityType: 'Reunión',
      lastActivityDaysAgo: 5,
      status: 'Activo',
      hasOpenDeals: false,
    },
    {
      name: 'Laura Fernández',
      email: 'laura.fernandez@techdata.com',
      phone: '+52 81 3456 7890',
      role: 'Decisor',
      company: 'Tech Data Services',
      owner: 'Carlos Ramírez',
      lastActivityType: 'Quote',
      lastActivityDaysAgo: 3,
      status: 'Activo',
      hasOpenDeals: true,
    },
    {
      name: 'Jorge Martínez',
      email: 'jorge.martinez@energy.com',
      phone: '+52 33 4567 8901',
      role: 'Técnico',
      company: 'Energy Solutions SA',
      owner: 'Pedro López',
      lastActivityType: 'Llamada',
      lastActivityDaysAgo: 7,
      status: 'No contactado',
      hasOpenDeals: true,
    },
    {
      name: 'Patricia Gómez',
      email: 'patricia.gomez@construction.com',
      phone: '+52 55 5678 9012',
      role: 'Compras',
      company: 'Construction Group',
      owner: 'Ana García',
      lastActivityType: 'Email',
      lastActivityDaysAgo: 0,
      status: 'Activo',
      hasOpenDeals: false,
    },
    {
      name: 'Miguel Torres',
      email: 'miguel.torres@automation.com',
      phone: '+52 81 6789 0123',
      role: 'Decisor',
      company: 'Automation Systems',
      owner: 'Carlos Ramírez',
      lastActivityType: 'Reunión',
      lastActivityDaysAgo: 2,
      status: 'Activo',
      hasOpenDeals: true,
    },
    {
      name: 'Andrea Herrera',
      email: 'andrea.herrera@process.com',
      phone: '+52 33 7890 1234',
      role: 'Técnico',
      company: 'Process Engineering',
      owner: 'Pedro López',
      lastActivityType: 'Llamada',
      lastActivityDaysAgo: 1,
      status: 'Activo',
      hasOpenDeals: true,
    },
  ];

  // ====== FILTROS REALES ======
  const [q, setQ] = React.useState('');
  const [showFilters, setShowFilters] = React.useState(false);

  const [roleFilter, setRoleFilter] = React.useState<'Todos' | Role>('Todos');
  const [companyFilter, setCompanyFilter] = React.useState<'Todas' | string>('Todas');
  const [ownerFilter, setOwnerFilter] = React.useState<'Todos' | string>('Todos');
  const [activityTypeFilter, setActivityTypeFilter] = React.useState<'Todas' | LastActivityType>('Todas');
  const [inactiveFilter, setInactiveFilter] = React.useState<'Todos' | '7+' | '14+' | '30+'>('Todos');
  const [openDealsFilter, setOpenDealsFilter] = React.useState<'Todos' | 'Sí' | 'No'>('Todos');
  const [statusFilter, setStatusFilter] = React.useState<'Todos' | Contact['status']>('Todos');

  // opciones relacionadas (derivadas de datos reales)
  const companyOptions = React.useMemo(() => {
    const set = new Set(contacts.map(c => c.company));
    return ['Todas', ...Array.from(set).sort()];
  }, [contacts]);

  const ownerOptions = React.useMemo(() => {
    const set = new Set(contacts.map(c => c.owner));
    return ['Todos', ...Array.from(set).sort()];
  }, [contacts]);

  const filteredContacts = React.useMemo(() => {
    const query = q.trim().toLowerCase();

    return contacts.filter(c => {
      // búsqueda
      if (query) {
        const hay = `${c.name} ${c.email} ${c.phone} ${c.company} ${c.owner} ${c.role}`.toLowerCase();
        if (!hay.includes(query)) return false;
      }

      // rol
      if (roleFilter !== 'Todos' && c.role !== roleFilter) return false;

      // empresa (relacionado a Companies)
      if (companyFilter !== 'Todas' && c.company !== companyFilter) return false;

      // owner
      if (ownerFilter !== 'Todos' && c.owner !== ownerFilter) return false;

      // tipo de actividad
      if (activityTypeFilter !== 'Todas' && c.lastActivityType !== activityTypeFilter) return false;

      // inactividad (en días)
      if (inactiveFilter !== 'Todos') {
        const threshold = inactiveFilter === '7+' ? 7 : inactiveFilter === '14+' ? 14 : 30;
        if (c.lastActivityDaysAgo < threshold) return false;
      }

      // deals abiertos (relacionado a Deals/Negocios)
      if (openDealsFilter !== 'Todos') {
        const want = openDealsFilter === 'Sí';
        if (c.hasOpenDeals !== want) return false;
      }

      // status
      if (statusFilter !== 'Todos' && c.status !== statusFilter) return false;

      return true;
    });
  }, [
    contacts,
    q,
    roleFilter,
    companyFilter,
    ownerFilter,
    activityTypeFilter,
    inactiveFilter,
    openDealsFilter,
    statusFilter,
  ]);

  const clearFilters = () => {
    setQ('');
    setRoleFilter('Todos');
    setCompanyFilter('Todas');
    setOwnerFilter('Todos');
    setActivityTypeFilter('Todas');
    setInactiveFilter('Todos');
    setOpenDealsFilter('Todos');
    setStatusFilter('Todos');
  };

  const getRoleBadgeVariant = (role: Role) => {
    if (role === 'Decisor') return 'default';
    if (role === 'Técnico') return 'secondary';
    return 'outline';
  };

  const getStatusBadge = (status: Contact['status']) => {
    if (status === 'Activo') return 'bg-green-100 text-green-700';
    if (status === 'No contactado') return 'bg-yellow-100 text-yellow-800';
    return 'bg-gray-100 text-gray-700';
  };

  const getActivityLabel = (t: LastActivityType, days: number) => {
    const when = days === 0 ? 'hoy' : days === 1 ? 'ayer' : `hace ${days} días`;
    return `${t} ${when}`;
  };

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      <Card className="bg-white border border-gray-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl">DINAMO BUSINESS MANAGEMENT CRM</h2>
            <Button className="bg-blue-600 hover:bg-blue-700">+ Nuevo Contacto</Button>
          </div>

          {/* Search + controls */}
          <div className="flex gap-3 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar contactos (nombre, correo, empresa, owner)..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm bg-white"
              />
            </div>

            {/* Quick filters (como HubSpot) */}
            <select
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
              value={ownerFilter}
              onChange={(e) => setOwnerFilter(e.target.value)}
            >
              {ownerOptions.map(o => (
                <option key={o} value={o}>
                  {o === 'Todos' ? 'Owner: Todos' : `Owner: ${o}`}
                </option>
              ))}
            </select>

            <select
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
              value={companyFilter}
              onChange={(e) => setCompanyFilter(e.target.value)}
            >
              {companyOptions.map(c => (
                <option key={c} value={c}>
                  {c === 'Todas' ? 'Empresa: Todas' : `Empresa: ${c}`}
                </option>
              ))}
            </select>

            <Button variant="outline" className="gap-2" onClick={() => setShowFilters(v => !v)}>
              <Filter className="h-4 w-4" />
              Filtros
            </Button>

            <Button variant="outline" className="gap-2" onClick={clearFilters}>
              <X className="h-4 w-4" />
              Limpiar
            </Button>
          </div>

          {/* Advanced filter panel */}
          {showFilters && (
            <div className="mt-4 border border-gray-200 rounded-xl p-4 bg-white">
              <div className="grid grid-cols-6 gap-3">
                <div className="col-span-2">
                  <label className="text-xs text-gray-600">Rol en Proyecto</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={roleFilter}
                    onChange={(e) => setRoleFilter(e.target.value as any)}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Decisor">Decisor</option>
                    <option value="Técnico">Técnico</option>
                    <option value="Compras">Compras</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-xs text-gray-600">Tipo de última actividad</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={activityTypeFilter}
                    onChange={(e) => setActivityTypeFilter(e.target.value as any)}
                  >
                    <option value="Todas">Todas</option>
                    <option value="Llamada">Llamada</option>
                    <option value="Email">Email</option>
                    <option value="Reunión">Reunión</option>
                    <option value="Quote">Quote</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-xs text-gray-600">Sin actividad</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={inactiveFilter}
                    onChange={(e) => setInactiveFilter(e.target.value as any)}
                  >
                    <option value="Todos">Todos</option>
                    <option value="7+">7+ días</option>
                    <option value="14+">14+ días</option>
                    <option value="30+">30+ días</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-xs text-gray-600">Negocios abiertos (Deals)</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={openDealsFilter}
                    onChange={(e) => setOpenDealsFilter(e.target.value as any)}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Sí">Sí</option>
                    <option value="No">No</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="text-xs text-gray-600">Estado del contacto</label>
                  <select
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as any)}
                  >
                    <option value="Todos">Todos</option>
                    <option value="Activo">Activo</option>
                    <option value="No contactado">No contactado</option>
                    <option value="No califica">No califica</option>
                  </select>
                </div>

                <div className="col-span-2 flex items-end text-xs text-gray-500">
                  Nota: Empresa y Deals son filtros “relacionados” (Companies/Deals).
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Cliente</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Email</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Teléfono</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Rol</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Empresa</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Última Actividad</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Estado</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Asesor Dinamo </th>
                <th className="text-center px-6 py-3 text-xs text-gray-600"></th>
              </tr>
            </thead>
            <tbody>
              {filteredContacts.map((contact, idx) => (
                <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-sm">
                        {contact.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      <span className="text-sm text-blue-600 hover:underline cursor-pointer">
                        {contact.name}
                      </span>
                      {contact.hasOpenDeals && (
                        <span className="ml-2 text-[10px] px-2 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700">
                          Deals activos
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Mail className="h-4 w-4 text-gray-400" />
                      {contact.email}
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Phone className="h-4 w-4 text-gray-400" />
                      {contact.phone}
                    </div>
                  </td>

                  <td className="px-6 py-4">
                    <Badge variant={getRoleBadgeVariant(contact.role) as any}>{contact.role}</Badge>
                  </td>

                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Building2 className="h-4 w-4 text-gray-400" />
                      {contact.company}
                    </div>
                  </td>

                  <td className="px-6 py-4 text-sm text-gray-600">
                    {getActivityLabel(contact.lastActivityType, contact.lastActivityDaysAgo)}
                  </td>

                  <td className="px-6 py-4">
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusBadge(contact.status)}`}>
                      {contact.status}
                    </span>
                  </td>

                  <td className="px-6 py-4 text-sm text-gray-700">{contact.owner}</td>

                  <td className="px-6 py-4 text-center">
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}

              {filteredContacts.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-6 py-12 text-center text-sm text-gray-600">
                    No hay contactos con los filtros actuales.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <span className="text-sm text-gray-600">
            Mostrando {filteredContacts.length} de {contacts.length} contactos
          </span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>
              Anterior
            </Button>
            <Button variant="outline" size="sm">
              Siguiente
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
