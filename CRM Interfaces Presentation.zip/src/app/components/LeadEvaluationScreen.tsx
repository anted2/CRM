import { useState } from "react";
import { Mail, Phone } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { Card, CardContent } from "@/app/components/ui/card";

const leads = [
  {
    id: 1,
    titulo: "Planta Concentradora Andina",
    empresa: "Minera Andina",
    contacto: "Carlos Ruiz",
    fecha: "2026-01-10",
    monto: "$5,000,000",
    tipoEpc: "Full",
    descripcion:
      "Proyecto EPC para el diseño, suministro e instalación de una planta concentradora para procesamiento de minerales.",
  },
  {
    id: 2,
    titulo: "Subestación Sur 220kV",
    empresa: "EnerSur",
    contacto: "María López",
    fecha: "2026-01-12",
    monto: "$1,200,000",
    tipoEpc: "Parcial",
    descripcion:
      "Ingeniería y construcción de una subestación eléctrica de alta tensión para distribución regional.",
  },
  {
    id: 3,
    titulo: "Riego Tecnificado Valle Norte",
    empresa: "AgroPerú",
    contacto: "Luis Gómez",
    fecha: "2026-01-15",
    monto: "$800,000",
    tipoEpc: "EPCM",
    descripcion:
      "Sistema de riego automatizado para optimizar el uso del agua en zonas agrícolas de alta demanda.",
  },
];

export default function LeadEvaluationScreen() {
  const [selected, setSelected] = useState(leads[0]);
  const [decision, setDecision] = useState("Califica");
  const [status, setStatus] = useState("NOT FIT");
  const [comment, setComment] = useState("");

  return (
    <div className="bg-gray-50 min-h-screen p-6 grid grid-cols-12 gap-4">
      {/* Lista de leads */}
      <Card className="col-span-3 p-2 overflow-y-auto">
        <h2 className="text-lg mb-4">Leads por evaluar</h2>
        {leads.map((l) => (
          <div
            key={l.id}
            onClick={() => setSelected(l)}
            className={`p-2 rounded-lg cursor-pointer mb-2 ${
              selected.id === l.id
                ? "bg-blue-100"
                : "hover:bg-gray-100"
            }`}
          >
            <p className="text-sm font-medium">{l.titulo}</p>
            <p className="text-xs text-gray-500">{l.empresa}</p>
          </div>
        ))}
      </Card>

      {/* Info central */}
      <Card className="col-span-6 p-4">
        <CardContent className="space-y-4">
          <div>
            <h2 className="text-md font-semibold">{selected.titulo}</h2>
            <p className="text-xs text-gray-500">{selected.empresa}</p>
          </div>

          {/* Info Cliente */}
          <div>
            <h3 className="text-lg font-semibold mb-2">Info del cliente</h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <strong>Cliente:</strong> {selected.empresa}
              </div>
              <div>
                <strong>Representante:</strong> {selected.contacto}
              </div>
              <div>
                <strong>Cargo:</strong> Gerente
              </div>
              <div>
                <strong>Teléfono:</strong> +51 999 888 777
              </div>
              <div>
                <strong>Correo:</strong> contacto@empresa.com
              </div>
              <div>
                <strong>País:</strong> Perú
              </div>
              <div>
                <strong>Industria:</strong> Minería
              </div>
              <div>
                <strong>Grupo:</strong> Andina Group
              </div>
            </div>
          </div>

          {/* Info Proyecto */}
          <div>
            <h3 className="text-lg font-semibold mb-2">
              Info del proyecto
            </h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <strong>Tipo EPC:</strong> {selected.tipoEpc}
              </div>
              <div>
                <strong>Monto estimado:</strong> {selected.monto}
              </div>
              <div>
                <strong>Fecha compra:</strong> 2026-06
              </div>
              <div className="col-span-2">
                <strong>Descripción:</strong>
                <textarea
                  readOnly
                  value={selected.descripcion}
                  className="w-full mt-1 px-2 py-1 border rounded-lg text-sm resize-none"
                  rows={3}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Right Column  */}
        <div className="col-span-3 space-y-6">

          {/* Contact Info */}
          <Card className="p-6">
            <h3 className="text-lg mb-4">Creador Dinamo</h3>
            <div className="flex items-start gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-blue-600 rounded-full flex items-center justify-center text-white">
                AG
              </div>
              <div>
                <p className="text-sm mb-1">Ana Garcia</p>
                <p className="text-xs text-gray-600">Jefe de Proyectos</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <Mail className="h-4 w-4 text-gray-400" />
                agarcia@dinamoi.com
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <Phone className="h-4 w-4 text-gray-400" />
                +51 81 1234 5678
              </div>
            </div>
        
          </Card>

          
        </div>

      {/* Evaluación */}
      <Card className="col-span-12 p-4 mt-4">
        <h3 className="text-lg mb-4">
          Evaluación
        </h3>
        <div className="grid grid-cols-2 gap-4 mb-3">
          <select
            value={decision}
            onChange={(e) => setDecision(e.target.value)}
            className="w-full px-3 py-2 border rounded-lg text-sm"
          >
            <option>Califica</option>
            <option>No califica</option>
          </select>
          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="w-full px-3 py-2 border rounded-lg text-sm"
          >
            <option>NOT FIT</option>
            <option>FALSE</option>
            <option>INFO QUOTE ONLY</option>
          </select>
        </div>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          placeholder="Comentario"
          className="w-full px-3 py-2 border rounded-lg text-sm"
        />
        <div className="flex justify-center">
        <Button className="w-50 mt-4 bg-blue-600 hover:bg-blue-700 text-white">
          GUARDAR
        </Button>
        </div>
      </Card>
    </div>
  );
}
