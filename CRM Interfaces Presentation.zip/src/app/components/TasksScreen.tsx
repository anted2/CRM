import React from 'react';
import { CheckCircle, Circle, Clock, AlertCircle, User, Calendar, Tag, FileText } from 'lucide-react';

interface Task {
  id: string;
  title: string;
  description: string;
  assignedTo: string;
  relatedTo: string;
  relatedType: 'Deal' | 'Project' | 'Lead';
  priority: 'high' | 'medium' | 'low';
  status: 'completed' | 'in-progress' | 'pending' | 'overdue';
  dueDate: string;
  completedDate?: string;
  tags: string[];
}

const tasks: Task[] = [
  {
    id: 'TSK-001',
    title: 'Enviar propuesta técnica revisada',
    description: 'Actualizar specs técnicas según feedback del cliente y enviar versión final',
    assignedTo: 'Carlos Méndez',
    relatedTo: 'Planta Solar 50MW Atacama',
    relatedType: 'Deal',
    priority: 'high',
    status: 'overdue',
    dueDate: '2026-01-27',
    tags: ['Propuesta', 'Técnico'],
  },
  {
    id: 'TSK-002',
    title: 'Reunión de kickoff con ENAP',
    description: 'Coordinar reunión inicial del proyecto con stakeholders clave',
    assignedTo: 'Ana Torres',
    relatedTo: 'Expansión Refinería Bio Bio',
    relatedType: 'Project',
    priority: 'high',
    status: 'in-progress',
    dueDate: '2026-01-30',
    tags: ['Reunión', 'Kickoff'],
  },
  {
    id: 'TSK-003',
    title: 'Actualizar costeo de materiales',
    description: 'Revisar precios actualizados de proveedores para cotización',
    assignedTo: 'Roberto Silva',
    relatedTo: 'Metro Santiago Línea 8',
    relatedType: 'Deal',
    priority: 'medium',
    status: 'pending',
    dueDate: '2026-02-05',
    tags: ['Costeo', 'Cotización'],
  },
  {
    id: 'TSK-004',
    title: 'Seguimiento PO pendiente MOP',
    description: 'Contactar al departamento de compras para estado de Purchase Order',
    assignedTo: 'Luis Ramírez',
    relatedTo: 'Puente Maipo-Rancagua',
    relatedType: 'Deal',
    priority: 'high',
    status: 'in-progress',
    dueDate: '2026-01-29',
    tags: ['PO', 'Seguimiento'],
  },
  {
    id: 'TSK-005',
    title: 'Revisión de planos arquitectónicos',
    description: 'Validar planos con equipo de ingeniería antes de enviar a cliente',
    assignedTo: 'María González',
    relatedTo: 'Hospital Regional Valdivia',
    relatedType: 'Deal',
    priority: 'medium',
    status: 'in-progress',
    dueDate: '2026-02-01',
    tags: ['Ingeniería', 'Planos'],
  },
  {
    id: 'TSK-006',
    title: 'Preparar documentación de cierre',
    description: 'Compilar informes finales y actas de entrega del proyecto',
    assignedTo: 'Patricia Vega',
    relatedTo: 'Data Center Providencia',
    relatedType: 'Project',
    priority: 'low',
    status: 'completed',
    dueDate: '2026-01-25',
    completedDate: '2026-01-24',
    tags: ['Cierre', 'Documentación'],
  },
  {
    id: 'TSK-007',
    title: 'Llamada de seguimiento con Minera Los Andes',
    description: 'Agendar llamada para actualizar estado de propuesta',
    assignedTo: 'Carlos Méndez',
    relatedTo: 'Campamento Minero El Teniente',
    relatedType: 'Lead',
    priority: 'medium',
    status: 'pending',
    dueDate: '2026-02-03',
    tags: ['Llamada', 'Seguimiento'],
  },
  {
    id: 'TSK-008',
    title: 'Solicitar aprobación Gate 3',
    description: 'Preparar documentación para gate de diseño y solicitar aprobación',
    assignedTo: 'Ana Torres',
    relatedTo: 'Expansión Refinería Bio Bio',
    relatedType: 'Deal',
    priority: 'high',
    status: 'pending',
    dueDate: '2026-01-31',
    tags: ['Gate', 'Aprobación'],
  },
];

export default function TasksScreen() {
  const getStatusBadge = (status: string) => {
    const statusConfig = {
      completed: { bg: 'bg-green-100', text: 'text-green-800', icon: CheckCircle },
      'in-progress': { bg: 'bg-blue-100', text: 'text-blue-800', icon: Clock },
      pending: { bg: 'bg-gray-100', text: 'text-gray-700', icon: Circle },
      overdue: { bg: 'bg-red-100', text: 'text-red-800', icon: AlertCircle },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    const Icon = config.icon;

    const labels = {
      completed: 'Completada',
      'in-progress': 'En Progreso',
      pending: 'Pendiente',
      overdue: 'Vencida',
    };

    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <Icon className="h-3 w-3" />
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const getPriorityBadge = (priority: string) => {
    const priorityConfig = {
      high: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
      medium: { bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-200' },
      low: { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200' },
    };

    const config = priorityConfig[priority as keyof typeof priorityConfig];

    return (
      <span className={`px-2 py-1 rounded text-xs font-medium border ${config.bg} ${config.text} ${config.border}`}>
        {priority === 'high' ? 'Alta' : priority === 'medium' ? 'Media' : 'Baja'}
      </span>
    );
  };

  const completedCount = tasks.filter((t) => t.status === 'completed').length;
  const inProgressCount = tasks.filter((t) => t.status === 'in-progress').length;
  const overdueCount = tasks.filter((t) => t.status === 'overdue').length;
  const pendingCount = tasks.filter((t) => t.status === 'pending').length;

  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl text-gray-900 mb-2">Tareas</h1>
        <p className="text-gray-600">
          Gestión de tareas y actividades relacionadas con negocios, proyectos y leads en proceso
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">Tareas Completadas</p>
            <CheckCircle className="h-5 w-5 text-green-600" />
          </div>
          <p className="text-3xl text-gray-900">{completedCount}</p>
          <p className="text-xs text-gray-500 mt-1">Total: {tasks.length} tareas</p>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">En Progreso</p>
            <Clock className="h-5 w-5 text-blue-600" />
          </div>
          <p className="text-3xl text-gray-900">{inProgressCount}</p>
          <p className="text-xs text-gray-500 mt-1">Trabajando activamente</p>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">Vencidas</p>
            <AlertCircle className="h-5 w-5 text-red-600" />
          </div>
          <p className="text-3xl text-gray-900">{overdueCount}</p>
          <p className="text-xs text-red-600 mt-1">Requieren atención</p>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">Pendientes</p>
            <Circle className="h-5 w-5 text-gray-600" />
          </div>
          <p className="text-3xl text-gray-900">{pendingCount}</p>
          <p className="text-xs text-gray-500 mt-1">Por iniciar</p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="bg-white rounded-lg border border-gray-200 mb-6">
        <div className="flex gap-2 p-4 border-b border-gray-200">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium">
            Todas ({tasks.length})
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200">
            Mis Tareas (5)
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200">
            Vencidas ({overdueCount})
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200">
            Alta Prioridad (4)
          </button>
        </div>
      </div>

      {/* Tasks Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">ID</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Tarea</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Asignado a</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Relacionado con</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Prioridad</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Estado</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Fecha Límite</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Tags</th>
              </tr>
            </thead>
            <tbody>
              {tasks.map((task) => (
                <tr key={task.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-4">
                    <span className="text-sm font-medium text-gray-900">{task.id}</span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="max-w-md">
                      <p className="text-sm font-medium text-gray-900 mb-1">{task.title}</p>
                      <p className="text-xs text-gray-500 line-clamp-2">{task.description}</p>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{task.assignedTo}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div>
                      <p className="text-sm text-gray-900">{task.relatedTo}</p>
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-50 text-blue-700 text-xs rounded mt-1">
                        <FileText className="h-3 w-3" />
                        {task.relatedType}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4">{getPriorityBadge(task.priority)}</td>
                  <td className="py-4 px-4">{getStatusBadge(task.status)}</td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{task.dueDate}</span>
                    </div>
                    {task.completedDate && (
                      <span className="text-xs text-green-600 mt-1 block">✓ {task.completedDate}</span>
                    )}
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex flex-wrap gap-1">
                      {task.tags.map((tag, idx) => (
                        <span key={idx} className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                          <Tag className="h-3 w-3" />
                          {tag}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-6 flex justify-end gap-3">
        <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
          Exportar Tareas
        </button>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center gap-2">
          <Circle className="h-4 w-4" />
          Nueva Tarea
        </button>
      </div>
    </div>
  );
}
