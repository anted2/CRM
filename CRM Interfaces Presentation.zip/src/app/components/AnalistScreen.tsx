import * as React from 'react';
import {
  BarChart3,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  ClipboardList,
  LineChart as LineChartIcon,
} from 'lucide-react';
import { Card } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
// Recharts
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from 'recharts';

type PipelineStage =
  | 'Lead recibido'
  | 'Qualified Lead'
  | 'Opportunity'
  | 'Quote Pending'
  | 'Awarded'
  | 'Pending PO'
  | 'Won (Order)'
  | 'Lost'
  | 'On Hold';

type LossReason =
  | 'FALSE'
  | 'NOT_FIT'
  | 'NO_BUDGET'
  | 'NO_RESPONSE'
  | 'COMPETITOR'
  | 'TIMING'
  | 'CLIENT_CANCELLED';

const LOSS_REASON_LABEL: Record<LossReason, string> = {
  FALSE: 'FALSE (No real)',
  NOT_FIT: 'NOT FIT (No es DINAMO)',
  NO_BUDGET: 'Sin presupuesto',
  NO_RESPONSE: 'Sin respuesta',
  COMPETITOR: 'Ganó competidor',
  TIMING: 'Timing / Postergado',
  CLIENT_CANCELLED: 'Cliente canceló',
};


type Deal = {
  name: string;
  client: string;
  amountUsd?: number; // para análisis rápido en números
  stage: PipelineStage;
  // Solo si se perdió:
  lostAtStage?: Exclude<PipelineStage, 'Lost' | 'Won (Order)' | 'On Hold'>;
  lossReason?: LossReason;
  createdAt: Date;
  lostDate?: Date;
  wonDate?: Date;
};

function formatMoneyCompactUSD(v: number) {
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(1)}K`;
  return `$${v.toFixed(0)}`;
}

// Tooltip simple para barras y líneas
function SimpleTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border rounded-lg px-3 py-2 text-xs shadow">
      <div className="font-semibold text-gray-900">{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} className="text-gray-700">
          {p.name}: <span className="font-semibold">{p.value}</span>
        </div>
      ))}
    </div>
  );
}

export default function AnalystScreen() {
  // Corregí el nombre a AnalystScreen (de Analist)
  
  // ======= Filtro de tiempo (nuevo) =======
  const [timeFilter, setTimeFilter] = React.useState<'all' | 'last30' | 'last90' | 'lastYear'>('all');

  // ======= DATA DEMO (reemplaza por tu fuente real, agregué fechas) =======
  const allDeals: Deal[] = [
    { name: 'HVAC-CM', client: 'Acme', stage: 'Won (Order)', amountUsd: 2100000, createdAt: new Date('2023-01-15'), wonDate: new Date('2023-03-20') },
    { name: 'SCADA Planta B', client: 'Process Eng', stage: 'Won (Order)', amountUsd: 1500000, createdAt: new Date('2023-02-10'), wonDate: new Date('2023-04-05') },
    { name: 'Piping Fase 2', client: 'PetroChemical', stage: 'Pending PO', amountUsd: 1800000, createdAt: new Date('2023-03-01') },
    { name: 'Data Center', client: 'Data Corp', stage: 'Quote Pending', amountUsd: 890000, createdAt: new Date('2023-04-15') },
    // Perdidos (Lost) con detalle:
    {
      name: 'HVAC Residencial',
      client: 'Persona Natural',
      stage: 'Lost',
      amountUsd: 0,
      lostAtStage: 'Lead recibido',
      lossReason: 'FALSE',
      createdAt: new Date('2023-01-05'),
      lostDate: new Date('2023-01-10'),
    },
    {
      name: 'Fabricación pesada X',
      client: 'Process Ltd',
      stage: 'Lost',
      amountUsd: 320000,
      lostAtStage: 'Qualified Lead',
      lossReason: 'NOT_FIT',
      createdAt: new Date('2023-02-20'),
      lostDate: new Date('2023-03-15'),
    },
    {
      name: 'Automatización Y',
      client: 'Indu SA',
      stage: 'Lost',
      amountUsd: 560000,
      lostAtStage: 'Opportunity',
      lossReason: 'NO_BUDGET',
      createdAt: new Date('2023-03-10'),
      lostDate: new Date('2023-04-20'),
    },
    {
      name: 'Sistema Control Z',
      client: 'Auto Systems',
      stage: 'Lost',
      amountUsd: 1200000,
      lostAtStage: 'Quote Pending',
      lossReason: 'COMPETITOR',
      createdAt: new Date('2023-04-05'),
      lostDate: new Date('2023-05-10'),
    },
    // On Hold / Postponed (si lo quieres)
    { name: 'Proyecto Postergado A', client: 'Cliente X', stage: 'On Hold', amountUsd: 400000, createdAt: new Date('2023-05-01') },
    // Más data para tendencias
    { name: 'Won Extra 1', client: 'Extra', stage: 'Won (Order)', amountUsd: 500000, createdAt: new Date('2023-05-15'), wonDate: new Date('2023-06-20') },
    { name: 'Lost Extra 1', client: 'Extra', stage: 'Lost', amountUsd: 300000, lostAtStage: 'Opportunity', lossReason: 'TIMING', createdAt: new Date('2023-06-10'), lostDate: new Date('2023-07-05') },
    { name: 'Won Extra 2', client: 'Extra', stage: 'Won (Order)', amountUsd: 800000, createdAt: new Date('2023-07-01'), wonDate: new Date('2023-08-15') },
    { name: 'Lost Extra 2', client: 'Extra', stage: 'Lost', amountUsd: 400000, lostAtStage: 'Pending PO', lossReason: 'CLIENT_CANCELLED', createdAt: new Date('2023-08-20'), lostDate: new Date('2023-09-10') },
  ];

  // Filtrar deals basado en timeFilter
  const now = new Date();
  const deals = allDeals.filter((d) => {
    const refDate = d.lostDate || d.wonDate || d.createdAt;
    if (timeFilter === 'last30') return refDate >= new Date(now.setDate(now.getDate() - 30));
    if (timeFilter === 'last90') return refDate >= new Date(now.setDate(now.getDate() - 90));
    if (timeFilter === 'lastYear') return refDate >= new Date(now.setFullYear(now.getFullYear() - 1));
    return true; // all
  });

  // ======= KPIs base (mejorados con win rate) =======
  const won = deals.filter(d => d.stage === 'Won (Order)');
  const lost = deals.filter(d => d.stage === 'Lost');
  const pendingPO = deals.filter(d => d.stage === 'Pending PO');
  const onHold = deals.filter(d => d.stage === 'On Hold');
  const totalClosed = won.length + lost.length;
  const winRate = totalClosed > 0 ? Math.round((won.length / totalClosed) * 100) : 0;
  const wonValue = won.reduce((s, d) => s + (d.amountUsd ?? 0), 0);
  const lostValue = lost.reduce((s, d) => s + (d.amountUsd ?? 0), 0);
  const pendingPOValue = pendingPO.reduce((s, d) => s + (d.amountUsd ?? 0), 0);
  const totalPipelineValue = deals.reduce((s, d) => s + (d.amountUsd ?? 0), 0);

  // ======= Graf 1: Ganados vs Perdidos (conteo y valor) con colores =======
  const wonLostBar = [
    {
      name: 'Ganados (Order)',
      count: won.length,
      value: Math.round(wonValue),
    },
    {
      name: 'Perdidos (Lost)',
      count: lost.length,
      value: Math.round(lostValue),
    },
    {
      name: 'Pendiente PO',
      count: pendingPO.length,
      value: Math.round(pendingPOValue),
    },
  ];

  // ======= Graf 2: Perdidos por razón con colores =======
  const lostByReasonMap = new Map<string, { name: string; count: number; value: number }>();
  for (const d of lost) {
    const key = d.lossReason ? LOSS_REASON_LABEL[d.lossReason] : 'Sin razón';
    const prev = lostByReasonMap.get(key) ?? { name: key, count: 0, value: 0 };
    prev.count += 1;
    prev.value += d.amountUsd ?? 0;
    lostByReasonMap.set(key, prev);
  }
  const lostByReason = Array.from(lostByReasonMap.values());

  // ======= Graf 3: Perdidos por etapa donde se perdió =======
  const lostByStageMap = new Map<string, { name: string; count: number; value: number }>();
  for (const d of lost) {
    const key = d.lostAtStage ?? 'Sin etapa';
    const prev = lostByStageMap.get(key) ?? { name: key, count: 0, value: 0 };
    prev.count += 1;
    prev.value += d.amountUsd ?? 0;
    lostByStageMap.set(key, prev);
  }
  const lostByStage = Array.from(lostByStageMap.values());

  // ======= Graf 4: Pie distribución (conteo) =======
  const pieData = [
    { name: 'Ganados', value: won.length },
    { name: 'Perdidos', value: lost.length },
    { name: 'Pend. PO', value: pendingPO.length },
    { name: 'On Hold', value: onHold.length },
  ];
  const pieColors = ['#22c55e', '#ef4444', '#f59e0b', '#64748b']; // Verde, rojo, amarillo, gris

  // ======= Nuevo Graf 5: Tendencia mensual (línea) =======
  // Agrupar por mes
  const monthlyDataMap = new Map<string, { name: string; wonValue: number; lostValue: number }>();
  for (const d of deals) {
    const refDate = d.lostDate || d.wonDate;
    if (!refDate) continue;
    const monthKey = `${refDate.getFullYear()}-${String(refDate.getMonth() + 1).padStart(2, '0')}`;
    const prev = monthlyDataMap.get(monthKey) ?? { name: monthKey, wonValue: 0, lostValue: 0 };
    if (d.stage === 'Won (Order)') prev.wonValue += d.amountUsd ?? 0;
    if (d.stage === 'Lost') prev.lostValue += d.amountUsd ?? 0;
    monthlyDataMap.set(monthKey, prev);
  }
  const monthlyData = Array.from(monthlyDataMap.values()).sort((a, b) => a.name.localeCompare(b.name));

  // ======= Nueva sección: Lista de perdidos recientes =======
  const recentLost = lost.sort((a, b) => (b.lostDate?.getTime() ?? 0) - (a.lostDate?.getTime() ?? 0)).slice(0, 5);

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      {/* Header con filtro */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-semibold text-gray-900">Análisis Comercial</h2>
          <p className="text-sm text-gray-500">
            Vista de decisiones: ganados vs perdidos, razones, etapas y tendencias.
          </p>
        </div>
        <Select value={timeFilter} onValueChange={(v: any) => setTimeFilter(v)}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Filtro de tiempo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todo</SelectItem>
            <SelectItem value="last30">Últimos 30 días</SelectItem>
            <SelectItem value="last90">Últimos 90 días</SelectItem>
            <SelectItem value="lastYear">Último año</SelectItem>
          </SelectContent>
        </Select>
      </div>
      {/* KPIs mejorados */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600">Ganados (Order)</p>
              <p className="text-3xl font-bold">{won.length}</p>
              <p className="text-xs text-gray-500 mt-1">{formatMoneyCompactUSD(wonValue)}</p>
            </div>
            <TrendingUp className="h-6 w-6 text-green-600" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600">Perdidos (Lost)</p>
              <p className="text-3xl font-bold">{lost.length}</p>
              <p className="text-xs text-gray-500 mt-1">{formatMoneyCompactUSD(lostValue)}</p>
            </div>
            <TrendingDown className="h-6 w-6 text-red-600" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600">Pendiente PO</p>
              <p className="text-3xl font-bold">{pendingPO.length}</p>
              <p className="text-xs text-gray-500 mt-1">{formatMoneyCompactUSD(pendingPOValue)}</p>
            </div>
            <AlertTriangle className="h-6 w-6 text-amber-600" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600">On Hold / Postponed</p>
              <p className="text-3xl font-bold">{onHold.length}</p>
              <p className="text-xs text-gray-500 mt-1">Para reactivar</p>
            </div>
            <ClipboardList className="h-6 w-6 text-slate-600" />
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-gray-600">Win Rate</p>
              <p className="text-3xl font-bold">{winRate}%</p>
              <p className="text-xs text-gray-500 mt-1">De cerrados</p>
            </div>
            <BarChart3 className="h-6 w-6 text-blue-600" />
          </div>
        </Card>
      </div>
      {/* Row 1: Ganados vs Perdidos + Pie + Tendencia */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-gray-700" />
              <h3 className="text-lg font-semibold">Ganados vs Perdidos (conteo y valor)</h3>
            </div>
            <Badge variant="secondary" className="text-xs">Resumen</Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={wonLostBar}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<SimpleTooltip />} />
                <Legend />
                <Bar dataKey="count" name="Cantidad" fill="#94a3b8" />
                <Bar dataKey="value" name="Valor USD" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Distribución (conteo)</h3>
            <Badge variant="secondary" className="text-xs">Pie</Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" outerRadius={95} label>
                  {pieData.map((_, idx) => (
                    <Cell key={idx} fill={pieColors[idx % pieColors.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <LineChartIcon className="h-5 w-5 text-gray-700" />
              <h3 className="text-lg font-semibold">Tendencia Mensual (valor)</h3>
            </div>
            <Badge variant="secondary" className="text-xs">Tendencia</Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<SimpleTooltip />} />
                <Legend />
                <Line type="monotone" dataKey="wonValue" name="Ganados USD" stroke="#22c55e" />
                <Line type="monotone" dataKey="lostValue" name="Perdidos USD" stroke="#ef4444" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
      {/* Row 2: Perdidos por razón y por etapa */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Perdidos por razón</h3>
            <Badge variant="secondary" className="text-xs">Loss reasons</Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lostByReason}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={60} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<SimpleTooltip />} />
                <Bar dataKey="count" name="Cantidad" fill="#94a3b8" />
                <Bar dataKey="value" name="Valor USD" fill="#ef4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Perdidos por etapa</h3>
            <Badge variant="secondary" className="text-xs">Lost at</Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lostByStage}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} interval={0} angle={-15} textAnchor="end" height={60} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<SimpleTooltip />} />
                <Bar dataKey="count" name="Cantidad" fill="#94a3b8" />
                <Bar dataKey="value" name="Valor USD" fill="#ef4444" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
      {/* Nueva sección: Lista de perdidos recientes */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Perdidos Recientes (Top 5)</h3>
          <Badge variant="secondary" className="text-xs">Detalles</Badge>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-700">
            <thead className="text-xs uppercase bg-gray-50">
              <tr>
                <th className="px-4 py-2">Nombre</th>
                <th className="px-4 py-2">Cliente</th>
                <th className="px-4 py-2">Etapa Perdida</th>
                <th className="px-4 py-2">Razón</th>
                <th className="px-4 py-2">Valor USD</th>
                <th className="px-4 py-2">Fecha Pérdida</th>
              </tr>
            </thead>
            <tbody>
              {recentLost.map((d, idx) => (
                <tr key={idx} className="border-b">
                  <td className="px-4 py-2">{d.name}</td>
                  <td className="px-4 py-2">{d.client}</td>
                  <td className="px-4 py-2">{d.lostAtStage}</td>
                  <td className="px-4 py-2">
                    <Badge variant="destructive">{d.lossReason ? LOSS_REASON_LABEL[d.lossReason] : 'Sin razón'}</Badge>
                  </td>
                  <td className="px-4 py-2">{formatMoneyCompactUSD(d.amountUsd ?? 0)}</td>
                  <td className="px-4 py-2">{d.lostDate?.toLocaleDateString() ?? 'N/A'}</td>
                </tr>
              ))}
              {recentLost.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-2 text-center text-gray-500">No hay perdidos recientes</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}