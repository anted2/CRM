import { Search, Filter, MoreVertical, FolderKanban, Building2, User, Calendar, TrendingUp } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Card } from '@/app/components/ui/card';

export default function ProjectsScreen() {
  const projects = [
    {
      projectCode: 'PRJ-2026-001',
      projectName: 'Proyecto Infraestructura Alpha',
      client: 'Alpha Corp',
      orderAssociated: 'ORD-2026-001',
      pm: 'Ing. Carlos Vega',
      status: 'En Ejecución',
      progress: 45,
      startDate: '10 Ene 2026',
      endDate: '15 Abr 2026',
      budget: '$2,100,000',
    },
    {
      projectCode: 'PRJ-2026-002',
      projectName: 'Sistema HVAC Industrial Complejo A',
      client: 'Industrial Solutions',
      orderAssociated: 'ORD-2026-002',
      pm: 'Ing. María Rodríguez',
      status: 'Inicio',
      progress: 15,
      startDate: '16 Ene 2026',
      endDate: '20 Mar 2026',
      budget: '$1,200,000',
    },
    {
      projectCode: 'PRJ-2026-003',
      projectName: 'Sistema Control Beta',
      client: 'Beta Industries',
      orderAssociated: 'ORD-2026-003',
      pm: 'Ing. Roberto Sánchez',
      status: 'En Ejecución',
      progress: 60,
      startDate: '12 Ene 2026',
      endDate: '30 Mar 2026',
      budget: '$1,500,000',
    },
    {
      projectCode: 'PRJ-2025-045',
      projectName: 'Modernización Subestación Eléctrica',
      client: 'Energy Corp',
      orderAssociated: 'ORD-2025-098',
      pm: 'Ing. Laura Hernández',
      status: 'Completado',
      progress: 100,
      startDate: '18 Nov 2025',
      endDate: '10 Ene 2026',
      budget: '$890,000',
    },
    {
      projectCode: 'PRJ-2025-042',
      projectName: 'Sistema Automatización Planta C',
      client: 'Manufacturing Plus',
      orderAssociated: 'ORD-2025-095',
      pm: 'Ing. Carlos Vega',
      status: 'En Ejecución',
      progress: 75,
      startDate: '25 Oct 2025',
      endDate: '28 Feb 2026',
      budget: '$1,750,000',
    },
    {
      projectCode: 'PRJ-2025-038',
      projectName: 'Infraestructura Data Center Principal',
      client: 'Tech Solutions',
      orderAssociated: 'ORD-2025-089',
      pm: 'Ing. María Rodríguez',
      status: 'Completado',
      progress: 100,
      startDate: '10 Sep 2025',
      endDate: '20 Dic 2025',
      budget: '$2,400,000',
    },
  ];

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'Inicio': 'bg-blue-100 text-blue-700',
      'En Ejecución': 'bg-green-100 text-green-700',
      'En Espera': 'bg-yellow-100 text-yellow-700',
      'Completado': 'bg-gray-100 text-gray-700',
    };
    return statusMap[status as keyof typeof statusMap] || 'bg-gray-100 text-gray-700';
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-green-500';
    if (progress >= 50) return 'bg-blue-500';
    if (progress >= 25) return 'bg-yellow-500';
    return 'bg-gray-400';
  };

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      <Card className="bg-white border border-gray-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl mb-1">Projects (Post-WON)</h2>
              <p className="text-sm text-gray-600">Gestión de proyectos en ejecución</p>
            </div>
            <Button className="bg-blue-600 hover:bg-blue-700">+ Nuevo Proyecto</Button>
          </div>
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar proyectos..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 p-6 border-b border-gray-200">
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl mb-1">{projects.length}</p>
            <p className="text-xs text-gray-600">Total Proyectos</p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-2xl text-blue-600 mb-1">
              {projects.filter(p => p.status === 'Inicio').length}
            </p>
            <p className="text-xs text-gray-600">Inicio</p>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-2xl text-green-600 mb-1">
              {projects.filter(p => p.status === 'En Ejecución').length}
            </p>
            <p className="text-xs text-gray-600">En Ejecución</p>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <p className="text-2xl text-gray-600 mb-1">
              {projects.filter(p => p.status === 'Completado').length}
            </p>
            <p className="text-xs text-gray-600">Completados</p>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Código Proyecto</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Nombre Proyecto</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Cliente</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Order Asociada</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">PM Asignado</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Estado</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Progreso</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Fecha Inicio</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Fecha Fin</th>
                <th className="text-center px-6 py-3 text-xs text-gray-600"></th>
              </tr>
            </thead>
            <tbody>
              {projects.map((project, idx) => (
                <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <FolderKanban className="h-4 w-4 text-blue-600" />
                      <span className="text-sm text-blue-600 hover:underline cursor-pointer">
                        {project.projectCode}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {project.projectName}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Building2 className="h-4 w-4 text-gray-400" />
                      {project.client}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <Badge variant="outline" className="text-xs">
                      {project.orderAssociated}
                    </Badge>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <User className="h-4 w-4 text-gray-400" />
                      {project.pm}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <Badge className={getStatusBadge(project.status)}>
                      {project.status}
                    </Badge>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${getProgressColor(project.progress)} transition-all`}
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-600 w-10 text-right">{project.progress}%</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      {project.startDate}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600">
                    {project.endDate}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <span className="text-sm text-gray-600">
            Mostrando {projects.length} de {projects.length} proyectos
          </span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>Anterior</Button>
            <Button variant="outline" size="sm">Siguiente</Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
