import { Search, Filter, Plus, DollarSign, User } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';

type QuoteStatus = 'Pendiente' | 'Enviado' | 'Revisión interna';
type POStatus = 'Pending' | 'Received' | 'Not required';

const quoteBadgeClass = (s: QuoteStatus) => {
  if (s === 'Enviado') return 'bg-blue-100 text-blue-700 border-blue-200';
  if (s === 'Revisión interna') return 'bg-yellow-100 text-yellow-700 border-yellow-200';
  return 'bg-gray-100 text-gray-700 border-gray-200';
};

const poBadgeClass = (s: POStatus) => {
  if (s === 'Received') return 'bg-green-100 text-green-700 border-green-200';
  if (s === 'Not required') return 'bg-slate-100 text-slate-700 border-slate-200';
  return 'bg-orange-100 text-orange-700 border-orange-200';
};

export default function DealsScreen({
  goToScreen,
}: {
  goToScreen: (index: number) => void;
}) {
  // 👉 PANTALLA 5 = DealDetailScreen
  const DEAL_DETAIL_INDEX = 6;

  const stages = [
    { name: 'Lead recibido', color: 'bg-gray-100 border-gray-300' },
    { name: 'Qualified Lead', color: 'bg-blue-100 border-blue-300' },
    { name: 'Opportunity', color: 'bg-blue-100 border-blue-300' },
    { name: 'Quote', color: 'bg-yellow-100 border-yellow-300' },
    { name: 'Awarded', color: 'bg-green-100 border-green-300' },
    { name: 'Won (Ordered)', color: 'bg-green-200 border-green-400' },
  ] as const;

  const dealsByStage: Record<string, any[]> = {
    // 🔹 Leads = 10M total
    'Lead recibido': [
      { name: 'Consulta Sistema HVAC-CM', client: 'Acme Corp', amount: '$4.0M', owner: 'Ana García' },
      { name: 'Infraestructura Red Industrial', client: 'BuildCo', amount: '$6.0M', owner: 'Pedro López' },
    ],

    'Qualified Lead': [
      { name: 'Sistema Eléctrico Backup', client: 'Tech Industries', amount: '$450K', owner: 'Ana García' },
      { name: 'Modernización Planta A', client: 'Manufacturing SA', amount: '$680K', owner: 'Pedro López' },
    ],

    'Opportunity': [
      {
        name: 'Ampliación Data Center',
        client: 'Data Corp',
        amount: '$890K',
        owner: 'Carlos Ramírez',
        status: 'Budget Quote',
        quoteStatus: 'Revisión interna' as QuoteStatus,
      },
      {
        name: 'Sistema Control Industrial',
        client: 'Auto Systems',
        amount: '$560K',
        owner: 'Ana García',
        status: 'Budget Quote',
        quoteStatus: 'Pendiente' as QuoteStatus,
      },
      {
        name: 'Infraestructura IT Completa',
        client: 'Global Tech',
        amount: '$1.2M',
        owner: 'Pedro López',
        status: 'Firm Quote',
        quoteStatus: 'Enviado' as QuoteStatus,
      },
    ],

    'Quote': [
      {
        name: 'Planta Piping Fase 2',
        client: 'PetroChemical Corp',
        amount: '$1.8M',
        owner: 'Ana García',
        status: 'Firm Quote',
        quoteStatus: 'Enviado' as QuoteStatus,
      },
      {
        name: 'HVAC Industrial Complejo A',
        client: 'Industrial Solutions',
        amount: '$1.2M',
        owner: 'Pedro López',
        status: 'Firm Quote',
        quoteStatus: 'Pendiente' as QuoteStatus,
      },
    ],

    'Awarded': [
      {
        name: 'Automatización Línea Z3',
        client: 'Manufacturing Inc',
        amount: '$950K',
        owner: 'Carlos Ramírez',
        poStatus: 'Pending' as POStatus,
      },
      {
        name: 'Sistema Eléctrico DC1',
        client: 'Tech Data Services',
        amount: '$780K',
        owner: 'Ana García',
        poStatus: 'Pending' as POStatus,
      },
      {
        name: 'HVAC Refuerzo Planta C',
        client: 'Industrial Solutions',
        amount: '$620K',
        owner: 'Pedro López',
        poStatus: 'Received' as POStatus,
      },
    ],

    'Won (Ordered)': [
      { name: 'Proyecto Infraestructura Alpha', client: 'Alpha Corp', amount: '$2.1M', owner: 'Ana García', po: 'PO-2024-001' },
      { name: 'Sistema Control Beta', client: 'Beta Industries', amount: '$1.5M', owner: 'Pedro López', po: 'PO-2024-003' },
    ],
  };

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl">Pipeline EPC</h2>
          <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
            <Plus className="h-4 w-4" />
            Nuevo Negocio
          </Button>
        </div>

        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Buscar negocios..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm bg-white"
            />
          </div>
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filtros
          </Button>
        </div>
      </div>

      {/* Kanban */}
      <div className="flex gap-4 overflow-x-auto pb-4">
        {stages.map((stage) => {
          const deals = dealsByStage[stage.name] || [];

          const totalValue = deals.reduce((sum, deal) => {
            const raw = String(deal.amount ?? '').replace(/[^0-9.]/g, '');
            return sum + (raw ? parseFloat(raw) : 0);
          }, 0);

          return (
            <div key={stage.name} className="flex-shrink-0 w-80">
              <Card className={`${stage.color} border-2 mb-3 p-4`}>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm">{stage.name}</h3>
                  <Badge variant="secondary" className="text-xs">
                    {deals.length}
                  </Badge>
                </div>
                <p className="text-xs text-gray-600">
                  {totalValue > 0 ? `$${(totalValue / 1000).toFixed(1)}M` : '$0'}
                </p>
              </Card>

              <div className="space-y-3">
                {deals.map((deal, idx) => (
                  <Card
                    key={idx}
                    onClick={() => goToScreen(DEAL_DETAIL_INDEX)}
                    className="p-4 bg-white border border-gray-200 hover:shadow-md transition-shadow cursor-pointer"
                  >
                    <h4 className="text-sm mb-2">{deal.name}</h4>
                    <p className="text-xs text-gray-600 mb-3">{deal.client}</p>

                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1 text-sm text-blue-600">
                        <DollarSign className="h-4 w-4" />
                        {deal.amount}
                      </div>
                    </div>

                    {deal.status && (
                      <div className="mb-2">
                        <Badge variant="outline" className="text-xs">
                          {deal.status}
                        </Badge>
                      </div>
                    )}

                    {deal.quoteStatus && (
                      <div className="mb-2">
                        <span className={`inline-flex px-2 py-1 text-xs rounded-md border ${quoteBadgeClass(deal.quoteStatus)}`}>
                          Quote: {deal.quoteStatus}
                        </span>
                      </div>
                    )}

                    {deal.poStatus && (
                      <div className="mb-2">
                        <span className={`inline-flex px-2 py-1 text-xs rounded-md border ${poBadgeClass(deal.poStatus)}`}>
                          PO: {deal.poStatus}
                        </span>
                      </div>
                    )}

                    {deal.po && (
                      <div className="mb-2">
                        <Badge className="text-xs bg-green-100 text-green-700">{deal.po}</Badge>
                      </div>
                    )}

                    <div className="flex items-center gap-1 text-xs text-gray-600 pt-2 border-t border-gray-100">
                      <User className="h-3 w-3" />
                      {deal.owner}
                    </div>
                  </Card>
                ))}

                <Button variant="ghost" className="w-full text-sm text-gray-500" size="sm">
                  + Agregar negocio
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
