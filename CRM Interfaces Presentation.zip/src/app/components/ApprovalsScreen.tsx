import React from 'react';
import { CheckCircle, XCircle, Clock, AlertTriangle, FileText, User, Calendar, DollarSign } from 'lucide-react';

interface ApprovalGate {
  id: string;
  dealName: string;
  company: string;
  stage: string;
  amount: string;
  gateType: string;
  status: 'pending' | 'approved' | 'rejected' | 'review';
  requestedBy: string;
  requestDate: string;
  daysWaiting: number;
  approvers: string[];
  description: string;
  risk: 'low' | 'medium' | 'high';
}

const approvals: ApprovalGate[] = [
  {
    id: 'APR-001',
    dealName: 'Planta Solar 50MW Atacama',
    company: 'SolarTech Chile',
    stage: 'Proposal Approval',
    amount: '$45,000,000',
    gateType: 'Gate 2 - Propuesta',
    status: 'pending',
    requestedBy: 'Carlos Méndez',
    requestDate: '2026-01-27',
    daysWaiting: 2,
    approvers: ['Director Comercial', 'CFO'],
    description: 'Aprobación de propuesta técnica y comercial para proyecto de energía solar',
    risk: 'high',
  },
  {
    id: 'APR-002',
    dealName: 'Expansión Refinería Bio Bio',
    company: 'ENAP',
    stage: 'Design Review',
    amount: '$78,500,000',
    gateType: 'Gate 3 - Diseño',
    status: 'review',
    requestedBy: 'Ana Torres',
    requestDate: '2026-01-25',
    daysWaiting: 4,
    approvers: ['Gerente Técnico', 'Director Proyectos'],
    description: 'Revisión de ingeniería básica y especificaciones técnicas',
    risk: 'medium',
  },
  {
    id: 'APR-003',
    dealName: 'Metro Santiago Línea 8',
    company: 'Metro S.A.',
    stage: 'Budget Approval',
    amount: '$125,000,000',
    gateType: 'Gate 4 - Presupuesto',
    status: 'approved',
    requestedBy: 'Roberto Silva',
    requestDate: '2026-01-20',
    daysWaiting: 9,
    approvers: ['CFO', 'CEO'],
    description: 'Aprobación de presupuesto final antes de emisión de PO',
    risk: 'high',
  },
  {
    id: 'APR-004',
    dealName: 'Puente Maipo-Rancagua',
    company: 'MOP - Ministerio',
    stage: 'Contract Review',
    amount: '$32,000,000',
    gateType: 'Gate 1 - Calificación',
    status: 'rejected',
    requestedBy: 'Luis Ramírez',
    requestDate: '2026-01-18',
    daysWaiting: 11,
    approvers: ['Director Legal'],
    description: 'Revisión de términos contractuales - Rechazado por claúsulas de penalidad',
    risk: 'low',
  },
  {
    id: 'APR-005',
    dealName: 'Hospital Regional Valdivia',
    company: 'Salud Pública',
    stage: 'Technical Approval',
    amount: '$56,000,000',
    gateType: 'Gate 3 - Diseño',
    status: 'pending',
    requestedBy: 'María González',
    requestDate: '2026-01-29',
    daysWaiting: 0,
    approvers: ['Gerente Técnico', 'QA Manager'],
    description: 'Aprobación de planos arquitectónicos y estructurales',
    risk: 'medium',
  },
];

export default function ApprovalsScreen() {
  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', icon: Clock },
      approved: { bg: 'bg-green-100', text: 'text-green-800', icon: CheckCircle },
      rejected: { bg: 'bg-red-100', text: 'text-red-800', icon: XCircle },
      review: { bg: 'bg-blue-100', text: 'text-blue-800', icon: FileText },
    };

    const config = statusConfig[status as keyof typeof statusConfig];
    const Icon = config.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <Icon className="h-3 w-3" />
        {status === 'pending' ? 'Pendiente' : status === 'approved' ? 'Aprobado' : status === 'rejected' ? 'Rechazado' : 'En Revisión'}
      </span>
    );
  };

  const getRiskBadge = (risk: string) => {
    const riskConfig = {
      low: { bg: 'bg-gray-100', text: 'text-gray-700' },
      medium: { bg: 'bg-orange-100', text: 'text-orange-700' },
      high: { bg: 'bg-red-100', text: 'text-red-700' },
    };

    const config = riskConfig[risk as keyof typeof riskConfig];

    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${config.bg} ${config.text}`}>
        <AlertTriangle className="h-3 w-3" />
        {risk === 'low' ? 'Bajo' : risk === 'medium' ? 'Medio' : 'Alto'}
      </span>
    );
  };

  const pendingCount = approvals.filter((a) => a.status === 'pending').length;
  const reviewCount = approvals.filter((a) => a.status === 'review').length;
  const approvedCount = approvals.filter((a) => a.status === 'approved').length;

  return (
    <div className="p-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl text-gray-900 mb-2">Aprobaciones - Gates de Control</h1>
        <p className="text-gray-600">
          Sistema de gates de aprobación para controlar el avance de negocios según etapas críticas del proceso EPC
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">Pendientes de Aprobación</p>
            <Clock className="h-5 w-5 text-yellow-600" />
          </div>
          <p className="text-3xl text-gray-900">{pendingCount}</p>
          <p className="text-xs text-gray-500 mt-1">Requieren acción inmediata</p>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">En Revisión</p>
            <FileText className="h-5 w-5 text-blue-600" />
          </div>
          <p className="text-3xl text-gray-900">{reviewCount}</p>
          <p className="text-xs text-gray-500 mt-1">En proceso de evaluación</p>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">Aprobadas (30d)</p>
            <CheckCircle className="h-5 w-5 text-green-600" />
          </div>
          <p className="text-3xl text-gray-900">{approvedCount}</p>
          <p className="text-xs text-gray-500 mt-1">Últimos 30 días</p>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm text-gray-600">Tiempo Promedio</p>
            <Calendar className="h-5 w-5 text-purple-600" />
          </div>
          <p className="text-3xl text-gray-900">5.2 días</p>
          <p className="text-xs text-gray-500 mt-1">Por gate de aprobación</p>
        </div>
      </div>

      {/* Gate Types Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
        <h3 className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Tipos de Gates en Proceso EPC
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-sm">
          <div>
            <span className="font-medium text-blue-800">Gate 1:</span>
            <span className="text-blue-700 ml-1">Calificación Lead</span>
          </div>
          <div>
            <span className="font-medium text-blue-800">Gate 2:</span>
            <span className="text-blue-700 ml-1">Aprobación Propuesta</span>
          </div>
          <div>
            <span className="font-medium text-blue-800">Gate 3:</span>
            <span className="text-blue-700 ml-1">Diseño e Ingeniería</span>
          </div>
          <div>
            <span className="font-medium text-blue-800">Gate 4:</span>
            <span className="text-blue-700 ml-1">Presupuesto Final</span>
          </div>
        </div>
      </div>

      {/* Approvals Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">ID</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Negocio / Empresa</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Gate Type</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Monto</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Estado</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Riesgo</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Solicitado Por</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Días Espera</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Aprobadores</th>
              </tr>
            </thead>
            <tbody>
              {approvals.map((approval) => (
                <tr key={approval.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-4 px-4">
                    <span className="text-sm font-medium text-gray-900">{approval.id}</span>
                  </td>
                  <td className="py-4 px-4">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{approval.dealName}</p>
                      <p className="text-xs text-gray-500">{approval.company}</p>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-sm text-gray-700">{approval.gateType}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-sm font-semibold text-gray-900 flex items-center gap-1">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      {approval.amount}
                    </span>
                  </td>
                  <td className="py-4 px-4">{getStatusBadge(approval.status)}</td>
                  <td className="py-4 px-4">{getRiskBadge(approval.risk)}</td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-700">{approval.requestedBy}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span
                      className={`text-sm font-medium ${
                        approval.daysWaiting > 5 ? 'text-red-600' : approval.daysWaiting > 2 ? 'text-yellow-600' : 'text-gray-700'
                      }`}
                    >
                      {approval.daysWaiting} días
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex flex-wrap gap-1">
                      {approval.approvers.map((approver, idx) => (
                        <span key={idx} className="px-2 py-1 bg-blue-50 text-blue-700 text-xs rounded border border-blue-200">
                          {approver}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-6 flex justify-end gap-3">
        <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
          Exportar Reporte
        </button>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">
          Configurar Aprobadores
        </button>
      </div>
    </div>
  );
}
