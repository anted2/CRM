import { Search, Filter, MoreVertical, Building2, MapPin, Clock } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Card } from '@/app/components/ui/card';

export default function CompaniesScreen() {
 const companies = [
  {
    name: 'PETROPERÚ',
    type: 'Cliente Final',
    industry: 'Petróleo y Gas',
    location: 'Lima, Perú',
    lastActivity: 'Reunión técnica hace 2 días',
    owner: 'Ana García',
    deals: 4,
    revenue: '$7.5M',
  },
  {
    name: 'AENZA ',
    type: 'EPC',
    industry: 'Ingeniería y Construcción',
    location: 'Lima, Perú',
    lastActivity: 'Propuesta enviada ayer',
    owner: 'Pedro López',
    deals: 6,
    revenue: '$12.3M',
  },
  {
    name: 'Southern Perú Copper Corporation',
    type: 'Cliente Final',
    industry: 'Minería',
    location: 'Arequipa, Perú',
    lastActivity: 'Visita a mina hace 3 días',
    owner: 'Ana García',
    deals: 5,
    revenue: '$18.9M',
  },
  {
    name: 'FERREYROS',
    type: 'Integrador',
    industry: 'Maquinaria y Servicios',
    location: 'Lima, Perú',
    lastActivity: 'Llamada comercial hace 1 día',
    owner: 'Carlos Ramírez',
    deals: 3,
    revenue: '$6.1M',
  },
  {
    name: 'ENGIE Energía Perú',
    type: 'Cliente Final',
    industry: 'Energía',
    location: 'Lima, Perú',
    lastActivity: 'Gate 2 aprobado hace 1 semana',
    owner: 'Pedro López',
    deals: 7,
    revenue: '$15.4M',
  },
  {
    name: 'Volcan Compañía Minera',
    type: 'Cliente Final',
    industry: 'Minería',
    location: 'Junín, Perú',
    lastActivity: 'Negociación hace 4 horas',
    owner: 'Ana García',
    deals: 4,
    revenue: '$9.8M',
  },
  {
    name: 'ABB Perú',
    type: 'Integrador',
    industry: 'Automatización',
    location: 'Lima, Perú',
    lastActivity: 'Demo técnica hace 2 días',
    owner: 'Carlos Ramírez',
    deals: 6,
    revenue: '$11.2M',
  },
  {
    name: 'Cosapi',
    type: 'EPC',
    industry: 'Ingeniería y Construcción',
    location: 'Lima, Perú',
    lastActivity: 'Contrato firmado ayer',
    owner: 'Pedro López',
    deals: 5,
    revenue: '$13.6M',
  },
];


  const getTypeBadgeVariant = (type: string) => {
    if (type === 'Cliente Final') return 'default';
    if (type === 'EPC') return 'secondary';
    return 'outline';
  };

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      <Card className="bg-white border border-gray-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl">Empresas</h2>
            <Button className="bg-blue-600 hover:bg-blue-700">+ Nueva Empresa</Button>
          </div>
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar empresas..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Nombre de la Empresa</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Tipo</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Industria</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Ubicación</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Última Actividad</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Deals</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Revenue</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Propietario</th>
                <th className="text-center px-6 py-3 text-xs text-gray-600"></th>
              </tr>
            </thead>
            <tbody>
              {companies.map((company, idx) => (
                <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-lg flex items-center justify-center text-white text-xs">
                        <Building2 className="h-5 w-5" />
                      </div>
                      <span className="text-sm text-blue-600 hover:underline cursor-pointer">
                        {company.name}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <Badge variant={getTypeBadgeVariant(company.type) as any}>
                      {company.type}
                    </Badge>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {company.industry}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      {company.location}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Clock className="h-4 w-4 text-gray-400" />
                      {company.lastActivity}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="inline-flex items-center justify-center px-2.5 py-1 bg-blue-50 text-blue-700 text-xs rounded">
                      {company.deals}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {company.revenue}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {company.owner}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <Button variant="ghost" size="sm">
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <span className="text-sm text-gray-600">
            Mostrando {companies.length} de {companies.length} empresas
          </span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled>Anterior</Button>
            <Button variant="outline" size="sm">Siguiente</Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
