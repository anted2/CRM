import { Search, Filter, AlertTriangle, Calendar, FileText, CheckCircle, XCircle } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Card } from '@/app/components/ui/card';

export default function AwardedPOScreen() {
  const awardedDeals = [
    {
      deal: 'Sistema HVAC Industrial Complejo A',
      client: 'Industrial Solutions',
      amount: '$1,200,000',
      awardedDate: '12 Ene 2026',
      poStatus: 'PO Recibida',
      poNumber: 'PO-2026-015',
      poDate: '14 Ene 2026',
      expectedPODate: '-',
      daysSinceAwarded: 4,
      canExecute: true,
    },
    {
      deal: 'Automatización Línea Producción Z3',
      client: 'Manufacturing Inc',
      amount: '$950,000',
      awardedDate: '10 Ene 2026',
      poStatus: 'Pendiente',
      poNumber: '-',
      poDate: '-',
      expectedPODate: '18 Ene 2026',
      daysSinceAwarded: 6,
      canExecute: false,
    },
    {
      deal: 'Infraestructura Eléctrica Data Center',
      client: 'Tech Data Services',
      amount: '$780,000',
      awardedDate: '08 Ene 2026',
      poStatus: 'Pendiente',
      poNumber: '-',
      poDate: '-',
      expectedPODate: '15 Ene 2026',
      daysSinceAwarded: 8,
      canExecute: false,
    },
    {
      deal: 'Proyecto Infraestructura Alpha',
      client: 'Alpha Corp',
      amount: '$2,100,000',
      awardedDate: '05 Ene 2026',
      poStatus: 'PO Recibida',
      poNumber: 'PO-2024-001',
      poDate: '07 Ene 2026',
      expectedPODate: '-',
      daysSinceAwarded: 11,
      canExecute: true,
    },
    {
      deal: 'Sistema Control Industrial SCADA',
      client: 'Process Engineering',
      amount: '$890,000',
      awardedDate: '13 Ene 2026',
      poStatus: 'Pendiente',
      poNumber: '-',
      poDate: '-',
      expectedPODate: '20 Ene 2026',
      daysSinceAwarded: 3,
      canExecute: false,
    },
    {
      deal: 'Sistema Control Beta',
      client: 'Beta Industries',
      amount: '$1,500,000',
      awardedDate: '06 Ene 2026',
      poStatus: 'PO Recibida',
      poNumber: 'PO-2024-003',
      poDate: '09 Ene 2026',
      expectedPODate: '-',
      daysSinceAwarded: 10,
      canExecute: true,
    },
  ];

  const pendingPO = awardedDeals.filter(d => d.poStatus === 'Pendiente');
  const withPO = awardedDeals.filter(d => d.poStatus === 'PO Recibida');

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      {/* Alert Banner */}
      <Card className="mb-6 p-4 bg-red-50 border-2 border-red-300">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="text-lg text-red-900 mb-1">⚠️ POLÍTICA CRÍTICA: NO EJECUTAR SIN PURCHASE ORDER</h3>
            <p className="text-sm text-red-800">
              Ningún proyecto puede iniciar ejecución sin PO confirmada. {pendingPO.length} negocios Awarded requieren PO.
            </p>
          </div>
        </div>
      </Card>

      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-6 mb-6">
        <Card className="p-6 bg-white border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl mb-1">{awardedDeals.length}</p>
              <p className="text-sm text-gray-600">Total Awarded</p>
            </div>
            <CheckCircle className="h-10 w-10 text-blue-600" />
          </div>
          <p className="text-sm text-gray-500 mt-2">
            ${(awardedDeals.reduce((sum, d) => sum + parseFloat(d.amount.replace(/[^0-9.]/g, '')), 0) / 1000000).toFixed(1)}M en valor
          </p>
        </Card>

        <Card className="p-6 bg-orange-50 border-2 border-orange-300">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl text-orange-700 mb-1">{pendingPO.length}</p>
              <p className="text-sm text-orange-900">Pending PO</p>
            </div>
            <AlertTriangle className="h-10 w-10 text-orange-600" />
          </div>
          <p className="text-sm text-orange-800 mt-2">
            ${(pendingPO.reduce((sum, d) => sum + parseFloat(d.amount.replace(/[^0-9.]/g, '')), 0) / 1000000).toFixed(1)}M bloqueados
          </p>
        </Card>

        <Card className="p-6 bg-green-50 border border-green-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl text-green-700 mb-1">{withPO.length}</p>
              <p className="text-sm text-green-900">Con PO</p>
            </div>
            <CheckCircle className="h-10 w-10 text-green-600" />
          </div>
          <p className="text-sm text-green-800 mt-2">
            Listos para ejecución
          </p>
        </Card>
      </div>

      <Card className="bg-white border border-gray-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl">Negocios Awarded - Control de Purchase Orders</h2>
          </div>
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar negocios awarded..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Negocio / Cliente</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Monto</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Fecha Awarded</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Días desde Awarded</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Estado PO</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Número PO</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Fecha PO</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Fecha Compromiso</th>
                <th className="text-center px-6 py-3 text-xs text-gray-600">Puede Ejecutar</th>
              </tr>
            </thead>
            <tbody>
              {awardedDeals.map((deal, idx) => (
                <tr 
                  key={idx} 
                  className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${
                    deal.poStatus === 'Pendiente' ? 'bg-orange-50' : ''
                  }`}
                >
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm text-gray-900">{deal.deal}</p>
                      <p className="text-xs text-gray-600">{deal.client}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900">
                    {deal.amount}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Calendar className="h-4 w-4 text-gray-400" />
                      {deal.awardedDate}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <Badge variant={deal.daysSinceAwarded > 7 ? 'destructive' : 'secondary'}>
                      {deal.daysSinceAwarded} días
                    </Badge>
                  </td>
                  <td className="px-6 py-4">
                    {deal.poStatus === 'PO Recibida' ? (
                      <Badge className="bg-green-100 text-green-700 border-green-200">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        PO Recibida
                      </Badge>
                    ) : (
                      <Badge className="bg-orange-100 text-orange-700 border-orange-200">
                        <AlertTriangle className="h-3 w-3 mr-1" />
                        Pendiente
                      </Badge>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    {deal.poNumber !== '-' ? (
                      <div className="flex items-center gap-2 text-sm text-blue-600">
                        <FileText className="h-4 w-4" />
                        {deal.poNumber}
                      </div>
                    ) : (
                      <span className="text-sm text-gray-400">-</span>
                    )}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {deal.poDate}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-700">
                    {deal.expectedPODate}
                  </td>
                  <td className="px-6 py-4 text-center">
                    {deal.canExecute ? (
                      <CheckCircle className="h-6 w-6 text-green-600 mx-auto" />
                    ) : (
                      <XCircle className="h-6 w-6 text-red-600 mx-auto" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">
              Mostrando {awardedDeals.length} negocios awarded
            </span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm">
                <div className="w-3 h-3 bg-orange-100 border border-orange-300 rounded"></div>
                <span className="text-gray-600">Pending PO</span>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled>Anterior</Button>
                <Button variant="outline" size="sm">Siguiente</Button>
              </div>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
