import { Search, Filter, MoreVertical, FileText, Calendar, AlertCircle, CheckCircle, User, Paperclip } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Card } from '@/app/components/ui/card';

export default function QuotesScreen() {
  const quotes = [
    {
      id: 'Q-2026-045',
      deal: 'Ampliación Planta Piping - Fase 2',
      client: 'PetroChemical Corp',
      type: 'Firm Quote',
      status: 'Sent',
      amount: '$1,800,000',
      dueDate: '18 Ene 2026',
      ae: 'Ing. Roberto Martínez',
      version: 'v2.1',
      overdue: true,
    },
    {
      id: 'Q-2026-046',
      deal: 'Sistema HVAC Industrial Complejo A',
      client: 'Industrial Solutions',
      type: 'Firm Quote',
      status: 'Awarded',
      amount: '$1,200,000',
      dueDate: '20 Ene 2026',
      ae: 'Ing. Laura Sánchez',
      version: 'v1.0',
      overdue: false,
    },
    {
      id: 'Q-2026-043',
      deal: 'Automatización Línea Producción Z3',
      client: 'Manufacturing Inc',
      type: 'Budget Quote',
      status: 'Pending',
      amount: '$950,000',
      dueDate: '22 Ene 2026',
      ae: 'Ing. Miguel Torres',
      version: 'v1.2',
      overdue: false,
    },
    {
      id: 'Q-2026-047',
      deal: 'Infraestructura Eléctrica Data Center',
      client: 'Tech Data Services',
      type: 'Firm Quote',
      status: 'Sent',
      amount: '$780,000',
      dueDate: '25 Ene 2026',
      ae: 'Ing. Roberto Martínez',
      version: 'v1.0',
      overdue: false,
    },
    {
      id: 'Q-2026-042',
      deal: 'Sistema Control Industrial SCADA',
      client: 'Process Engineering',
      type: 'Info Quote',
      status: 'Draft',
      amount: '$560,000',
      dueDate: '28 Ene 2026',
      ae: 'Ing. Laura Sánchez',
      version: 'v1.0',
      overdue: false,
    },
    {
      id: 'Q-2026-041',
      deal: 'Modernización Planta Química B',
      client: 'Chemical Industries',
      type: 'Firm Quote',
      status: 'Sent',
      amount: '$2,100,000',
      dueDate: '10 Ene 2026',
      ae: 'Ing. Miguel Torres',
      version: 'v3.0',
      overdue: true,
    },
    {
      id: 'Q-2026-048',
      deal: 'Sistema Instrumentación Refinería',
      client: 'Oil Refinery Co',
      type: 'Budget Quote',
      status: 'Pending',
      amount: '$1,450,000',
      dueDate: '30 Ene 2026',
      ae: 'Ing. Roberto Martínez',
      version: 'v1.1',
      overdue: false,
    },
  ];

  const getStatusBadge = (status: string) => {
    const variants = {
      'Draft': 'secondary',
      'Sent': 'default',
      'Pending': 'outline',
      'Awarded': 'default',
    };
    const colors = {
      'Draft': 'bg-gray-100 text-gray-700',
      'Sent': 'bg-blue-100 text-blue-700',
      'Pending': 'bg-yellow-100 text-yellow-700',
      'Awarded': 'bg-green-100 text-green-700',
    };
    return { variant: variants[status as keyof typeof variants] || 'default', color: colors[status as keyof typeof colors] || '' };
  };

  const getTypeBadge = (type: string) => {
    if (type === 'Firm Quote') return 'default';
    if (type === 'Budget Quote') return 'secondary';
    return 'outline';
  };

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      <Card className="bg-white border border-gray-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl">Quotes (Cotizaciones)</h2>
            <Button className="bg-blue-600 hover:bg-blue-700">+ Nueva Quote</Button>
          </div>
          <div className="flex gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar cotizaciones..."
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Filter className="h-4 w-4" />
              Filtros
            </Button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Quote ID</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Negocio / Cliente</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Tipo</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Estado</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Monto</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Due Date</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">AE Asignado</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Versión</th>
                <th className="text-left px-6 py-3 text-xs text-gray-600">Archivos</th>
                <th className="text-center px-6 py-3 text-xs text-gray-600"></th>
              </tr>
            </thead>
            <tbody>
              {quotes.map((quote, idx) => {
                const statusBadge = getStatusBadge(quote.status);
                return (
                  <tr key={idx} className={`border-b border-gray-100 hover:bg-gray-50 transition-colors ${quote.overdue ? 'bg-red-50' : ''}`}>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-blue-600" />
                        <span className="text-sm text-blue-600 hover:underline cursor-pointer">
                          {quote.id}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="text-sm text-gray-900">{quote.deal}</p>
                        <p className="text-xs text-gray-600">{quote.client}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant={getTypeBadge(quote.type) as any}>
                        {quote.type}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Badge className={statusBadge.color}>
                        {quote.status === 'Awarded' && <CheckCircle className="h-3 w-3 mr-1" />}
                        {quote.status}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {quote.amount}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {quote.overdue && <AlertCircle className="h-4 w-4 text-red-600" />}
                        <Calendar className="h-4 w-4 text-gray-400" />
                        <span className={`text-sm ${quote.overdue ? 'text-red-600' : 'text-gray-700'}`}>
                          {quote.dueDate}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-sm text-gray-700">
                        <User className="h-4 w-4 text-gray-400" />
                        {quote.ae}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <Badge variant="outline" className="text-xs">
                        {quote.version}
                      </Badge>
                    </td>
                    <td className="px-6 py-4">
                      <Button variant="ghost" size="sm" className="gap-1">
                        <Paperclip className="h-4 w-4" />
                        <span className="text-xs">PDF</span>
                      </Button>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
          <span className="text-sm text-gray-600">
            Mostrando {quotes.length} de {quotes.length} cotizaciones
          </span>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-sm text-red-600">
              <AlertCircle className="h-4 w-4" />
              {quotes.filter(q => q.overdue).length} Quotes vencidas
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled>Anterior</Button>
              <Button variant="outline" size="sm">Siguiente</Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}
