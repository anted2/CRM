import * as React from 'react';
import { AlertCircle, TrendingUp, DollarSign, FileText, Clock } from 'lucide-react';
import { Card } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';

/* ================= TYPES ================= */

type AlertType = 'critical' | 'warning' | 'info';

type PipelineStage =
  | 'Lead recibido'
  | 'Lead perdido'
  | 'Qualified Lead'
  | 'Opportunity'
  | 'Quote Pending'
  | 'Awarded'
  | 'Pending PO'
  | 'Won (Ordered)';

type PipelineItem = {
  stage: PipelineStage;
  count: number;
  valueUsd: number;
};

type KPI = {
  label: string;
  value: string;
  change: string;
  icon: any;
};

type AlertItem = {
  type: AlertType;
  message: string;
  count: number;
};

type TopDeal = {
  name: string;
  client: string;
  valueUsd: number;
  stage: Exclude<PipelineStage, 'Lead recibido'>;
  probability: number;
  risk: 'low' | 'medium' | 'high';
};

type MainLevelKey = 'LEADS' | 'QUALIFIED' | 'OPPORTUNITY' | 'CLOSING';

/* ================= HELPERS ================= */

function formatMoneyCompactUSD(v: number) {
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(1)}K`;
  return `$${v.toFixed(0)}`;
}

/*  UN SOLO COLOR PARA TODO CLOSING */
function getStageColor(stage: PipelineStage) {
  if (
    stage === 'Quote Pending' ||
    stage === 'Awarded' ||
    stage === 'Pending PO' ||
    stage === 'Won (Ordered)'
  ) {
    return 'bg-gray-50 border-gray-300 text-gray-800';
  }
  return '';
}

function clsAlertBg(type: AlertType) {
  if (type === 'critical') return 'bg-red-50 border-red-200';
  if (type === 'warning') return 'bg-orange-50 border-orange-200';
  return 'bg-blue-50 border-blue-200';
}

function clsDot(type: AlertType) {
  if (type === 'critical') return 'bg-red-600';
  if (type === 'warning') return 'bg-orange-600';
  return 'bg-blue-600';
}

/* ================= FUNNEL ================= */

function Funnel4Levels({ pipelineData }: { pipelineData: PipelineItem[] }) {
  const levels = [
    { key: 'LEADS', title: 'LEADS', color: 'bg-violet-600', stages: ['Lead recibido'] },
    { key: 'QUALIFIED', title: 'QUALIFIED', color: 'bg-slate-700', stages: ['Qualified Lead'] },
    { key: 'OPPORTUNITY', title: 'OPPORTUNITY', color: 'bg-emerald-600', stages: ['Opportunity'] },
    {
      key: 'CLOSING',
      title: 'CLOSING',
      color: 'bg-amber-500',
      stages: ['Quote Pending', 'Awarded', 'Pending PO'], // ✅ quitamos Won (Order) de aquí
    },
    {
      key: 'ORDER',
      title: 'ORDER',
      color: 'bg-blue-700',
      stages: ['Won (Ordered)'], // ✅ nuevo nivel final
    },
  ] as const;

  const map = new Map<PipelineStage, PipelineItem>();
  pipelineData.forEach(p => map.set(p.stage, p));

  const groups = levels.map(l => {
    const items = l.stages.map(s => map.get(s)).filter(Boolean) as PipelineItem[];
    return {
      ...l,
      items,
      totalValue: items.reduce((sum, i) => sum + i.valueUsd, 0),
    };
  });

  // ✅ ahora son 5 niveles
  const widths = ['w-[92%]', 'w-[80%]', 'w-[68%]', 'w-[56%]', 'w-[44%]'];
  const clip = 'polygon(0% 0%, 100% 0%, 92% 100%, 8% 100%)';

  return (
    <div className="grid grid-cols-1 md:grid-cols-[340px_1fr] gap-6">
      {/* FUNNEL */}
      <div className="flex flex-col items-center gap-3">
        {groups.map((g, idx) => (
          <div key={g.key} className={`${widths[idx]} mx-auto`}>
            <div
              className={`${g.color} text-white`}
              style={{ clipPath: clip, borderRadius: 16 }}
            >
              <div className="py-5 text-center">
                <div className="text-sm font-bold tracking-wide">{g.title}</div>
                <div className="text-xs opacity-90 mt-1">
                  {formatMoneyCompactUSD(g.totalValue)}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* LISTA DERECHA */}
      <div className="space-y-4">
        {groups.map(g => (
          <div key={g.key} className="bg-white border rounded-xl p-4">
            <h4 className="text-sm font-semibold mb-3">{g.title}</h4>

            {/* SIMPLE (niveles con 1 solo stage) */}
            {g.key !== 'CLOSING' && (
              <div className="flex items-center justify-between px-3 py-2 border rounded-lg bg-gray-50">
                <span className="text-sm font-medium">{g.items[0]?.stage}</span>
                <div className="flex items-center gap-6 text-sm">
                  <span className="text-gray-600">{g.items[0]?.count ?? 0}</span>
                  <span className="font-semibold">
                    {formatMoneyCompactUSD(g.items[0]?.valueUsd ?? 0)}
                  </span>
                </div>
              </div>
            )}

            {/* CLOSING DETALLADO */}
            {g.key === 'CLOSING' && (
              <div className="space-y-2">
                {g.items.map(it => (
                  <div
                    key={it.stage}
                    className={`flex items-center justify-between px-3 py-2 rounded-lg border ${getStageColor(it.stage)}`}
                  >
                    <div>
                      <div className="text-sm font-medium">{it.stage}</div>
                      <div className="text-xs text-gray-500">{it.count} negocios</div>
                    </div>
                    <div className="text-sm font-semibold">
                      {formatMoneyCompactUSD(it.valueUsd)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}


/* ================= DASHBOARD ================= */

export default function DashboardScreen() {
  const pipelineData: PipelineItem[] = [
    { stage: 'Lead recibido', count: 12, valueUsd: 10_000_000 },
    { stage: 'Qualified Lead', count: 8, valueUsd: 2_400_000 },
    { stage: 'Opportunity', count: 15, valueUsd: 8_700_000 },
    { stage: 'Quote Pending', count: 9, valueUsd: 5_200_000 },
    { stage: 'Awarded', count: 6, valueUsd: 4_100_000 },
    { stage: 'Pending PO', count: 4, valueUsd: 2_800_000 },
    { stage: 'Won (Ordered)', count: 18, valueUsd: 12_500_000 },
  ];

  const kpis: KPI[] = [
    { label: 'Pipeline Comercial', value: '$23.2M', change: '+12%', icon: DollarSign },
    { label: 'Conversión a Contrato', value: '12%', change: '+3%', icon: TrendingUp },
    { label: 'Cotizaciones', value: '23', change: '+5', icon: FileText },
    { label: 'Ciclo de Venta', value: '45 días', change: '-5d', icon: Clock },
  ];

  const alerts: AlertItem[] = [
    { type: 'critical', message: '4 cotizaciones vencidas requieren acción inmediata', count: 4 },
    { type: 'warning', message: '6 negocios Awarded sin Orden de Compra (PO)', count: 6 },
    { type: 'info', message: '3 aprobaciones internas pendientes', count: 3 },
  ];

  const topDeals: TopDeal[] = [
    {
      name: 'Ampliación Planta Piping - Fase 2',
      client: 'PetroChemical Corp',
      valueUsd: 1_800_000,
      stage: 'Quote Pending',
      probability: 65,
      risk: 'medium',
    },
    {
      name: 'Sistema HVAC Industrial Complejo A',
      client: 'Industrial Solutions',
      valueUsd: 1_200_000,
      stage: 'Awarded',
      probability: 90,
      risk: 'low',
    },
    {
      name: 'Automatización Línea Producción Z3',
      client: 'Manufacturing Inc',
      valueUsd: 950_000,
      stage: 'Opportunity',
      probability: 40,
      risk: 'high',
    },
  ];

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold">DINAMO BUSINESS MANAGEMENT CRM</h2>
        <p className="text-sm text-gray-500"> </p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {kpis.map((k, i) => {
          const Icon = k.icon;
          return (
            <Card key={i} className="p-6">
              <div className="flex justify-between">
                <div>
                  <p className="text-sm text-gray-600">{k.label}</p>
                  <p className="text-3xl font-bold">{k.value}</p>
                  <p className="text-sm text-green-600">{k.change}</p>
                </div>
                <Icon className="h-6 w-6 text-blue-600" />
              </div>
            </Card>
          );
        })}
      </div>

      {/* FUNNEL */}
      <Card className="p-6 mb-8">
        <h3 className="text-lg font-semibold mb-4"> Pipeline Comercial DINAMO </h3>
        <Funnel4Levels pipelineData={pipelineData} />
      </Card>

      {/* TOP DEALS + ALERTAS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* NEGOCIOS PRINCIPALES */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4">Negocios Principales</h3>
          <div className="space-y-4">
            {topDeals.map((deal, idx) => (
              <div
                key={idx}
                className="p-4 bg-gray-50 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium mb-1">{deal.name}</h4>
                    <p className="text-xs text-gray-600">{deal.client}</p>
                  </div>
                  <Badge
                    variant={
                      deal.risk === 'low'
                        ? 'default'
                        : deal.risk === 'medium'
                        ? 'secondary'
                        : 'destructive'
                    }
                    className="text-xs"
                  >
                    {deal.risk === 'low'
                      ? 'Bajo'
                      : deal.risk === 'medium'
                      ? 'Medio'
                      : 'Alto'} Riesgo
                  </Badge>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-blue-600 font-medium">
                    {formatMoneyCompactUSD(deal.valueUsd)}
                  </span>
                  <span className="text-gray-600">{deal.stage}</span>
                  <span className="text-gray-900 font-medium">
                    Prob: {deal.probability}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* ALERTAS */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-red-600" />
            Alertas y Acciones Requeridas
          </h3>
          <div className="space-y-3">
            {alerts.map((a, i) => (
              <div
                key={i}
                className={`flex items-center justify-between p-4 rounded-lg border ${clsAlertBg(a.type)}`}
              >
                <div className="flex items-center gap-3">
                  <span className={`w-2 h-2 rounded-full ${clsDot(a.type)}`} />
                  <span className="text-gray-900">{a.message}</span>
                </div>
                <Badge>{a.count}</Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
