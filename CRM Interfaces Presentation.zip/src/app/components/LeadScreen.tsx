import { ArrowLeft, DollarSign, Calendar, User, Building2, FileText, CheckCircle, AlertTriangle, Clock, Mail, Phone, Plus } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Card } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';

export default function DealDetailScreen() {
  return (
    <div className="bg-gray-50 min-h-full">
      {/* Header */}
      

      <div className="p-8 grid grid-cols-3 gap-6">
        {/* Left Column - Main Info */}
        <div className="col-span-2 space-y-6">
          {/* Deal Stage & Value */}
          <Card className="p-6 bg-white border border-gray-200">
            <h3 className="text-lg mb-4">Información del Cliente</h3>
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Cliente</label>
                <div className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <Building2 className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-blue-600">PetroChemical Corp</span>
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Industria</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option>Petrolera</option>
                  <option>Minera</option>
                  <option>b</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">País</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option>Perú</option>
                  <option>Chile</option>
                  <option>México</option>
                </select>
               </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Grupo Empresarial</label>
                <input 
                  type="text" 
                  value="Am"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                  readOnly
                />
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Representante</label>
                <div className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                  <User className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">Carlos Méndez</span>
                </div>
                </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Cargo/Posición</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                  <option>Jefe</option>
                  <option>Vendedor</option>
                  <option>w</option>
                </select>
              </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Número</label>
                <div className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                  <Phone className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">967 854 323</span>
                </div>
                </div>
              <div>
                <label className="text-xs text-gray-600 mb-1 block">Correo</label>
                <div className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
                  <Mail className="h-4 w-4 text-gray-400" />
                  <span className="text-sm">carlos.mendez@petrochemical.com</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Project Properties */}
<Card className="p-6 bg-white border border-gray-200">
  <h3 className="text-lg mb-1">Información del Proyecto</h3>
  
  {/* Correlativo debajo del título */}
  <p className="text-xs text-gray-500 mb-4"># Correlativo: 828678674234</p>

  <div className="grid grid-cols-2 gap-6">
    {/* Nombre del proyecto */}
    <div>
      <label className="text-xs text-gray-600 mb-1 block">Nombre referencial del Proyecto</label>
      <input 
        type="text" 
        value="Ampliación Industrial"
        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
        readOnly
      />
    </div>

    {/* Fecha estimada de compra */}
    <div>
      <label className="text-xs text-gray-600 mb-1 block">Fecha estimada de compra</label>
      <div className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50">
        <Calendar className="h-4 w-4 text-gray-400" />
        <span className="text-sm">20/04/2024</span>
      </div>
    </div>

    {/* Descripción ocupa dos filas a la izquierda */}
    <div className="row-span-2">
      <label className="text-xs text-gray-600 mb-1 block">Descripción</label>
      <textarea
        value="A"
        readOnly
        className="w-full h-full px-3 py-2 border border-gray-300 rounded-lg text-sm resize-none"
      />
    </div>

    {/* Monto estimado arriba a la derecha */}
    <div>
      <label className="text-xs text-gray-600 mb-1 block">Monto estimado ($USD)</label>
      <input 
        type="number" 
        value="5000000"
        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
        readOnly
      />
    </div>

    {/* Tipo de EPC abajo a la derecha */}
    <div>
      <label className="text-xs text-gray-600 mb-1 block">Tipo de EPC</label>
      <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
        <option>Parcial</option>
        <option>Full</option>
        <option>Mixto</option>
        <option>EPCM</option>
      </select>
    </div>
  </div>
</Card>


          {/* Registrar Lead */}
          
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Registrar LEAD
              </Button>
          
        </div>

        {/* Right Column  */}
        <div className="space-y-6">

          {/* Contact Info */}
          <Card className="p-6 bg-white border border-gray-200">
            <h3 className="text-lg mb-4">Creador Dinamo</h3>
            <div className="flex items-start gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-blue-600 rounded-full flex items-center justify-center text-white">
                AG
              </div>
              <div>
                <p className="text-sm mb-1">Ana Garcia</p>
                <p className="text-xs text-gray-600">Jefe de Proyectos</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <Mail className="h-4 w-4 text-gray-400" />
                agarcia@dinamoi.com
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-700">
                <Phone className="h-4 w-4 text-gray-400" />
                +51 81 1234 5678
              </div>
            </div>
        
          </Card>

          
        </div>
      </div>
    </div>
  );
}