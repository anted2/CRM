import * as React from 'react';
import {
  Search,
  BarChart3,
  Briefcase,
  FileText,
  ClipboardCheck,
  Users,
  Building2,
  Phone,
  FolderKanban,
  ListTodo,
  ShoppingCart,
  ArrowRight,
  Clock,
} from 'lucide-react';
import { Card } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';

type QuickLink = {
  title: string;
  subtitle: string;
  icon: any;
  screenIndex: number; // <- a qué pantalla manda (tu currentScreen)
  badge?: string;
};

type RecentItem = {
  title: string;
  meta: string;
  screenIndex: number;
  tag?: string;
};

export default function InicioScreen({
  goToScreen,
}: {
  goToScreen: (index: number) => void;
}) {
  const [q, setQ] = React.useState('');

  // ✅ Ajusta los screenIndex según tu arreglo screens (más abajo te digo)
  const quickLinks: QuickLink[] = [
    { title: 'KPI', subtitle: 'Dashboard Comercial', icon: BarChart3, screenIndex: 0, badge: 'Principal' },
    { title: 'Negocios', subtitle: 'Pipeline EPC', icon: Briefcase, screenIndex: 4, badge: 'Kanban' },
    { title: 'Cotizaciones', subtitle: 'Quotes', icon: FileText, screenIndex: 6 },
    { title: 'Aprobaciones', subtitle: 'Gates', icon: ClipboardCheck, screenIndex: 7 },
    { title: 'Contactos', subtitle: 'Clientes & Leads', icon: Users, screenIndex: 2 },
    { title: 'Empresas', subtitle: 'Cuentas', icon: Building2, screenIndex: 3 },
    { title: 'Pedidos', subtitle: 'Orders', icon: ShoppingCart, screenIndex: 9 },
    { title: 'Proyectos', subtitle: 'Post-WON', icon: FolderKanban, screenIndex: 10 },
    { title: 'Tareas', subtitle: 'To-do', icon: ListTodo, screenIndex: 11 },
    { title: 'Llamadas', subtitle: 'Calls', icon: Phone, screenIndex: 12 },
  ];

  const recent: RecentItem[] = [
    { title: 'Planta Piping Fase 2', meta: 'Quote Pending · PetroChemical Corp', screenIndex: 4, tag: 'Deal' },
    { title: 'PO-2024-003', meta: 'Won (Order) · Beta Industries', screenIndex: 9, tag: 'Order' },
    { title: 'Aprobación interna pendiente', meta: 'Gate 3 · Ingeniería', screenIndex: 7, tag: 'Gate' },
    { title: 'Nuevo contacto: Juan Pérez', meta: 'Industrial Solutions', screenIndex: 2, tag: 'Contacto' },
  ];

  const filteredLinks = quickLinks.filter(l => {
    const text = `${l.title} ${l.subtitle}`.toLowerCase();
    return text.includes(q.toLowerCase());
  });

  return (
    <div className="p-8 bg-gray-50 min-h-full">
      {/* Header tipo Azure */}
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-gray-900"> </h2>
        <p className="text-sm text-gray-500">Accesos rápidos, recientes y navegación del CRM</p>

        {/* Search */}
        <div className="mt-4 relative max-w-3xl">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            type="text"
            placeholder="Buscar módulos (KPI, Negocios, Cotizaciones...)"
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl text-sm bg-white"
          />
        </div>
      </div>

      {/* Acciones rápidas */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="p-5 bg-white border border-gray-200 rounded-xl">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-sm font-semibold text-gray-900">Acciones rápidas</div>
              <div className="text-xs text-gray-500 mt-1">Más usado</div>
            </div>
            <Badge variant="secondary" className="text-xs">Shortcuts</Badge>
          </div>

          <div className="mt-4 flex flex-col gap-2">
            <Button className="justify-between" onClick={() => goToScreen(4)}>
              Ir a Negocios (Pipeline) <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="justify-between" onClick={() => goToScreen(6)}>
              Ver Cotizaciones <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="justify-between" onClick={() => goToScreen(7)}>
              Revisar Aprobaciones <ArrowRight className="h-4 w-4" />
            </Button>
          </div>
        </Card>

        <Card className="p-5 bg-white border border-gray-200 rounded-xl lg:col-span-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-gray-900">Resumen</div>
              <div className="text-xs text-gray-500 mt-1"> </div>
            </div>
            <Badge className="text-xs">DINAMO</Badge>
          </div>

          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 rounded-lg border bg-gray-50">
              <div className="text-xs text-gray-500">Módulos</div>
              <div className="text-xl font-bold text-gray-900">12</div>
            </div>
            <div className="p-3 rounded-lg border bg-gray-50">
              <div className="text-xs text-gray-500">Última sesión</div>
              <div className="text-sm font-semibold text-gray-900 flex items-center gap-2">
                <Clock className="h-4 w-4" /> Hoy
              </div>
            </div>
            <div className="p-3 rounded-lg border bg-gray-50">
              <div className="text-xs text-gray-500">Pendientes</div>
              <div className="text-xl font-bold text-gray-900">3</div>
            </div>
            <div className="p-3 rounded-lg border bg-gray-50">
              <div className="text-xs text-gray-500">Alertas</div>
              <div className="text-xl font-bold text-gray-900">2</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Tiles tipo Azure */}
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-gray-900">Servicios / Módulos</h3>
        <p className="text-xs text-gray-500">Haz click en una tarjeta para abrir el módulo</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {filteredLinks.map((l) => {
          const Icon = l.icon;
          return (
            <button
              key={l.title}
              onClick={() => goToScreen(l.screenIndex +1 )} // 👈 ojo: aquí depende de tu índice (ver nota abajo)
              className="text-left"
              type="button"
            >
              <Card className="p-5 bg-white border border-gray-200 rounded-xl hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-gray-100 border">
                      <Icon className="h-5 w-5 text-gray-700" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-gray-900">{l.title}</div>
                      <div className="text-xs text-gray-500">{l.subtitle}</div>
                    </div>
                  </div>
                  {l.badge && <Badge className="text-xs">{l.badge}</Badge>}
                </div>

                <div className="mt-4 text-xs text-gray-500 flex items-center gap-2">
                  Abrir módulo <ArrowRight className="h-4 w-4" />
                </div>
              </Card>
            </button>
          );
        })}
      </div>

      {/* Recientes */}
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-gray-900">Recientes</h3>
        <p className="text-xs text-gray-500">Acceso rápido a lo último que se trabajó</p>
      </div>

      <Card className="bg-white border border-gray-200 rounded-xl">
        <div className="p-4">
          <div className="divide-y">
            {recent.map((r, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => goToScreen(r.screenIndex - 1)} // 👈 igual que arriba (ver nota)
                className="w-full text-left py-3 flex items-center justify-between hover:bg-gray-50 rounded-lg px-2"
              >
                <div>
                  <div className="text-sm font-medium text-gray-900">{r.title}</div>
                  <div className="text-xs text-gray-500">{r.meta}</div>
                </div>
                <div className="flex items-center gap-2">
                  {r.tag && <Badge variant="secondary" className="text-xs">{r.tag}</Badge>}
                  <ArrowRight className="h-4 w-4 text-gray-400" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}
